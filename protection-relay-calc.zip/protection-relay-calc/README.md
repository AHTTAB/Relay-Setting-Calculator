# ⚡ Calcul Réglage des Protections — ONEE

Application web interactive pour le calcul et la génération des fiches de réglage des protections de lignes 225 kV.

---

## 🚀 Démarrage rapide

### Prérequis
- [Node.js](https://nodejs.org/) version **18** ou supérieure
- npm (inclus avec Node.js)

### Installation

```bash
# 1. Aller dans le dossier du projet
cd protection-relay-calc

# 2. Installer les dépendances
npm install

# 3. Lancer en mode développement
npm run dev
```

Ouvrir ensuite : **http://localhost:5173**

### Build de production

```bash
npm run build
npm run preview
```

---

## 📋 Fonctionnalités

| Onglet | Description |
|--------|-------------|
| **Général** | Informations du départ, résumé des calculs, liste des protections |
| **Ligne** | Saisie des segments (longueur, alliage, R/km, X/km), calcul automatique des impédances |
| **Réducteurs** | Rapport TC/TT, facteur de conversion, impédance vue secondaire Zd |
| **Zones** | Portée des zones (%), compensation kZ, temporisations, tableau récapitulatif |
| **P444** | Fiche de réglage complète Protection distance Alstom/GE |
| **D60** | Fiche de réglage complète Protection distance GE Multilin |
| **DBF** | Fiche relais défaillance disjoncteur hardware dédié |
| **D25** | Fiche Synchrochek – Contrôle de synchronisme |
| **P142** 🆕 | Fiche complète Alstom P142 : 50BF + 79 réenclencheur + 50/51 + 67N + 59N + 74 TCS |

---

## 📐 Formules utilisées

```
Z_total = √(R² + X²)
Angle   = arctan(X / R)
Zd      = Z_prim × (CT_ratio / VT_ratio)
kZ      = (Z0 − Z1) / (3 × Z1)   →  0.67 pour Almec 570 mm²
Z1      = Zd × z1_%
Blinder = 0.423 × Zd
```

---

## 🏗 Structure du projet

```
protection-relay-calc/
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
├── public/
│   └── favicon.svg
└── src/
    ├── main.jsx
    ├── index.css
    └── App.jsx          ← Toute la logique et l'UI
```

---

## 📄 Exemple de données (Poste HASSAN 1er)

| Paramètre | Valeur |
|-----------|--------|
| Tension | 225 kV |
| Alliage | Almec 570 mm² |
| L1 (Hassan – Tazarte) | 48,553 km |
| L2 (Hassan – UR II) | 63,712 km |
| L_total | 112,265 km |
| R total | 7,8586 Ω |
| X total | 44,4457 Ω |
| Z total | 45,1351 Ω |
| Rapport TT | 220 000 / 100 V |
| Rapport TC | 1000 / 1 A |
| **Zd (impédance vue)** | **20,52 Ω** |

---

*ONEE – Office National de l'Électricité et de l'Eau Potable — Pôle Industriel — Direction Centrale Transport*
