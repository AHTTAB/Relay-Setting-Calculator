import { useState, useMemo } from "react";

/* ═══════════════════════════════════════════════════
   UTILITIES
════════════════════════════════════════════════════ */
const round = (v, d = 3) => (isNaN(v) ? 0 : +v.toFixed(d));
const toDeg = (r) => (r * 180) / Math.PI;
const pf    = (v, d = 3) => round(parseFloat(v) || 0, d);
const fmt   = (v) => (v === null || v === undefined ? "—" : v);

/* ═══════════════════════════════════════════════════
   SMALL SHARED COMPONENTS
════════════════════════════════════════════════════ */

/* Labelled input */
function IF({ label, value, onChange, unit, readOnly, hint, type = "text", wide }) {
  return (
    <div className="flex items-start gap-2 mb-2.5">
      <label className="text-xs text-slate-400 flex-shrink-0 pt-2 leading-tight" style={{ width: wide ? 200 : 176 }}>
        {label}
      </label>
      <div className="flex items-center gap-2 flex-1 min-w-0">
        <input
          type={type}
          value={value}
          readOnly={readOnly}
          onChange={onChange ? (e) => onChange(e.target.value) : undefined}
          className={`px-3 py-1.5 rounded text-sm w-full max-w-xs font-mono transition-all ${
            readOnly
              ? "bg-slate-800 border border-amber-500/40 text-amber-300 cursor-default"
              : "bg-slate-900 border border-slate-600 text-slate-100 focus:border-amber-400 focus:ring-1 focus:ring-amber-400/30 outline-none"
          }`}
        />
        {unit && <span className="text-xs text-slate-500 flex-shrink-0 w-12">{unit}</span>}
      </div>
      {hint && <span className="text-xs text-slate-600 mt-2 italic hidden md:block">{hint}</span>}
    </div>
  );
}

/* Section title with amber bar */
function ST({ children }) {
  return (
    <div className="flex items-center gap-2 mb-3 mt-5 first:mt-0">
      <div className="w-1 h-4 bg-amber-400 rounded-full flex-shrink-0" />
      <h3 className="text-xs font-bold text-amber-400 uppercase tracking-widest">{children}</h3>
    </div>
  );
}

/* White card */
function Card({ children, className = "" }) {
  return (
    <div className={`bg-slate-900 border border-slate-700 rounded-xl p-5 ${className}`}>
      {children}
    </div>
  );
}

/* Table row for settings sheets */
function SR({ label, value, highlight, bold, indent, sub }) {
  return (
    <tr className={`border-b border-slate-800 ${highlight ? "bg-amber-500/10" : "hover:bg-slate-800/30"}`}>
      <td
        className={`py-1.5 px-3 text-xs leading-snug ${indent ? "pl-7" : ""} ${
          bold ? "text-slate-200 font-semibold" : "text-slate-400"
        }`}
      >
        {label}
        {sub && <span className="block text-slate-600 text-xs font-normal">{sub}</span>}
      </td>
      <td
        className={`py-1.5 px-3 text-right text-xs font-mono ${
          highlight ? "text-amber-300 font-bold" : bold ? "text-slate-100 font-semibold" : "text-slate-300"
        }`}
      >
        {fmt(value)}
      </td>
    </tr>
  );
}

/* Table with optional title */
function STable({ title, accent, children }) {
  const colors = {
    amber:  "bg-amber-900/40 text-amber-300",
    blue:   "bg-blue-900/40 text-blue-300",
    green:  "bg-green-900/40 text-green-300",
    orange: "bg-orange-900/40 text-orange-300",
    purple: "bg-purple-900/40 text-purple-300",
    red:    "bg-red-900/40 text-red-300",
    cyan:   "bg-cyan-900/40 text-cyan-300",
    slate:  "bg-slate-800 text-slate-200",
  };
  return (
    <div className="mb-4 rounded-lg overflow-hidden border border-slate-700">
      {title && (
        <div className={`px-3 py-1.5 ${accent ? colors[accent] : colors.slate}`}>
          <span className="text-xs font-bold uppercase tracking-wider">{title}</span>
        </div>
      )}
      <table className="w-full">
        <tbody>{children}</tbody>
      </table>
    </div>
  );
}

/* Stat card */
function Stat({ label, value, unit, sub, color = "amber" }) {
  const c = { amber: "text-amber-400", cyan: "text-cyan-400", green: "text-green-400", rose: "text-rose-400", slate: "text-slate-300", purple: "text-purple-400" };
  return (
    <div className="bg-slate-800 rounded-lg p-3 border border-slate-700">
      <p className="text-xs text-slate-500 mb-1 leading-none">{label}</p>
      <p className={`text-lg font-bold font-mono leading-none ${c[color]}`}>
        {value}
        {unit && <span className="text-xs ml-1 text-slate-500">{unit}</span>}
      </p>
      {sub && <p className="text-xs text-slate-600 mt-1">{sub}</p>}
    </div>
  );
}

/* Header banner for each relay sheet */
function RelayHeader({ code, name, color, poste, tension, dep1, dep2, date }) {
  const bg = {
    blue:   "from-blue-950 to-blue-900 border-blue-700",
    green:  "from-green-950 to-green-900 border-green-700",
    orange: "from-orange-950 to-orange-900 border-orange-700",
    purple: "from-purple-950 to-purple-900 border-purple-700",
    red:    "from-red-950 to-red-900 border-red-700",
  };
  const tx = { blue: "text-blue-400", green: "text-green-400", orange: "text-orange-400", purple: "text-purple-400", red: "text-red-400" };
  return (
    <div className={`bg-gradient-to-r ${bg[color]} rounded-xl p-4 border mb-4`}>
      <p className={`text-xs font-bold uppercase tracking-widest mb-1 ${tx[color]}`}>
        Fiche de Réglage Provisoire · DOS.FR01.DPS02 · Indice 00
      </p>
      <h2 className="text-base font-bold text-white">PROTECTION {code} — {name}</h2>
      <p className={`${tx[color]} text-xs mt-1`}>
        Poste : <strong className="text-white">{poste}</strong>
        &nbsp;|&nbsp; Départ {tension} KV N°: {dep1} + {dep2}
        &nbsp;|&nbsp; Date : {date}
      </p>
    </div>
  );
}

/* Multi-column zone table */
function ZoneTable({ rows, zones = ["Z1","Z2","Z3","Z4","Zp"], accentColor = "amber" }) {
  const c = { amber: "text-amber-400", green: "text-green-400", red: "text-red-400", blue: "text-blue-400" };
  return (
    <div className="rounded-lg overflow-hidden border border-slate-700 mb-4">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-slate-800 text-slate-400 text-xs border-b border-slate-700">
              <th className="py-2 px-3 text-left font-medium">Paramètre</th>
              {zones.map((z) => (
                <th key={z} className={`py-2 px-3 text-center font-bold ${c[accentColor]}`}>{z}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row, i) => (
              <tr key={i} className={`border-b border-slate-800 ${row.hi ? "bg-amber-500/5" : "hover:bg-slate-800/30"}`}>
                <td className={`py-1.5 px-3 text-xs ${row.bold ? "text-slate-200 font-semibold" : "text-slate-400"}`}>
                  {row.lbl}
                </td>
                {row.vals.map((v, j) => (
                  <td key={j} className={`py-1.5 px-3 text-xs text-center font-mono
                    ${row.hi  ? `${c[accentColor]} font-bold text-sm` :
                      row.bold ? "text-slate-100 font-semibold" : "text-slate-300"}`}>
                    {fmt(v)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════
   MAIN APP
════════════════════════════════════════════════════ */
export default function App() {
  const [activeTab, setActiveTab] = useState(0);

  /* ──────────── STATE ──────────── */
  const [G, setG] = useState({
    poste:      "HASSAN 1er",
    tension:    "225",
    depart1:    "25-66 TAZARTE",
    depart2:    "25-100 UR II",
    date:       "22/05/2025",
    ficheNo:    "",
    elaborePar: "KHECHAB",
    refDoc:     "DOS.FR01.DPS02",
    indice:     "00",
  });

  const [segs, setSegs] = useState([
    { id:1, name:"Hassan 1er – Tazarte", alloy:"Almec", section:"570", length:"48.553", r_km:"0.0700", x_km:"0.3959" },
    { id:2, name:"Hassan 1er – UR II",   alloy:"Almec", section:"570", length:"63.712", r_km:"0.0700", x_km:"0.3959" },
  ]);

  const [red, setRed] = useState({
    vt_prim:"220000", vt_sec:"100",
    ct_prim:"1000",   ct_sec:"1",
  });

  const [zp, setZp] = useState({
    z1_pct:"61.1", z2_pct:"120", zp_pct:"140", z3_pct:"175.6", z4_pct:"35.1",
    kz:"0.67", kz_arg:"0",
    tZ1:"0", tZ2:"400", tZ3:"3200", tZ4:"3200", tZp:"1000",
    r1g_factor:"1.45", r1ph_factor:"1.31",
    recl_t1:"1500", recl_tblock:"60000",
  });

  /* P142 specific settings */
  const [p142, setP142] = useState({
    /* 50BF */
    bf_i_phase:  "0.10",
    bf_i_neutre: "0.10",
    bf_t1:       "100",
    bf_t2:       "150",
    bf_t3:       "200",
    bf_t_reset:  "30",
    /* 51 / 50 */
    i_inst_pct:  "150",
    i_def_pct:   "120",
    t_def:       "0.5",
    /* 67N – Direction terre */
    dir67n_i0:   "0.05",
    dir67n_t:    "1.0",
    dir67n_angle:"75",
    /* 59N */
    u0_seuil:    "5",
    u0_t:        "1.5",
    /* 74 TCS */
    tcs_i:       "0.020",
    tcs_t:       "2.0",
    /* 79 Reenclencheur */
    r79_mode:    "1",
    r79_t_dead1: "0.5",
    r79_t_dead2: "10",
    r79_t_rec:   "30",
    r79_n_cycles:"2",
    /* LED / logique */
    prot_mode:   "1",
    trip_mode:   "3p",
    in_nom:      "1",
  });

  const ug  = (k, v) => setG(s => ({ ...s, [k]: v }));
  const ur  = (k, v) => setRed(s => ({ ...s, [k]: v }));
  const uz  = (k, v) => setZp(s => ({ ...s, [k]: v }));
  const up1 = (k, v) => setP142(s => ({ ...s, [k]: v }));
  const us  = (id, k, v) => setSegs(s => s.map(x => x.id === id ? { ...x, [k]: v } : x));
  const addSeg = () => setSegs(s => [...s, {
    id: Date.now(), name:`Segment ${s.length+1}`, alloy:"Almec",
    section:"570", length:"0", r_km:"0.0700", x_km:"0.3959",
  }]);
  const delSeg = id => setSegs(s => s.length > 1 ? s.filter(x => x.id !== id) : s);

  /* ──────────── CALCULATIONS ──────────── */
  const C = useMemo(() => {
    const segC = segs.map(s => {
      const len = pf(s.length), r = pf(s.r_km,4), x = pf(s.x_km,4);
      return { ...s, R: round(r*len,4), X: round(x*len,4), Z: round(Math.sqrt((r*len)**2+(x*len)**2),4), z_km: round(Math.sqrt(r**2+x**2),4) };
    });
    const Rt  = segC.reduce((a,s) => a + s.R, 0);
    const Xt  = segC.reduce((a,s) => a + s.X, 0);
    const Zt  = Math.sqrt(Rt**2 + Xt**2);
    const Lt  = segs.reduce((a,s) => a + pf(s.length), 0);
    const ang = toDeg(Math.atan2(Xt, Rt));

    const VTp = pf(red.vt_prim), VTs = pf(red.vt_sec);
    const CTp = pf(red.ct_prim), CTs = pf(red.ct_sec);
    const vtr = VTp / VTs, ctr = CTp / CTs;
    const cv  = ctr / vtr;

    const Zd  = Zt * cv;
    const Rd  = Rt * cv;
    const Xd  = Xt * cv;
    const kz  = pf(zp.kz,4);
    const Z0  = Zt * (1 + 3*kz);
    const Z0d = Z0 * cv;

    const z1 = round(Zd * pf(zp.z1_pct) / 100);
    const z2 = round(Zd * pf(zp.z2_pct) / 100);
    const z3 = round(Zd * pf(zp.z3_pct) / 100);
    const z4 = round(Zd * pf(zp.z4_pct) / 100);
    const zPilote = round(Zd * pf(zp.zp_pct) / 100);

    const r1g  = round(z3 * pf(zp.r1g_factor));
    const r1ph = round(z3 * pf(zp.r1ph_factor));
    const blinder    = round(0.423 * Zd);
    const porteeAv   = round(1.3 * z2);
    const porteeArr  = round(0.35 * Zd);

    // P142 derived
    const In      = pf(p142.in_nom);
    const In_prim = CTp;
    const bf_ih   = round(pf(p142.bf_i_phase) * In, 3);
    const i_inst  = round(In_prim * pf(p142.i_inst_pct) / 100, 0);
    const i_def   = round(In_prim * pf(p142.i_def_pct)  / 100, 0);

    return {
      segC, Rt:round(Rt,4), Xt:round(Xt,4), Zt:round(Zt,4), Lt:round(Lt,3), ang:round(ang,2),
      Zd:round(Zd,3), Rd:round(Rd,3), Xd:round(Xd,3),
      Z0:round(Z0,4), Z0d:round(Z0d,3),
      vtr, ctr, cv:round(cv,5),
      z1, z2, z3, z4, zPilote,
      r1g, r1ph, blinder, porteeAv, porteeArr,
      vt_sec_ph: round(VTs/Math.sqrt(3),1),
      kz,
      // P142
      bf_ih, i_inst, i_def,
      In_prim: CTp,
    };
  }, [segs, red, zp, p142]);

  /* ══════════════════════════════════════════
     TAB 0 – GÉNÉRAL
  ══════════════════════════════════════════ */
  const tabGeneral = (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
      <Card>
        <ST>Informations du Départ</ST>
        <IF label="Poste"         value={G.poste}      onChange={v=>ug("poste",v)} />
        <IF label="Tension (kV)"  value={G.tension}    onChange={v=>ug("tension",v)} type="number" unit="kV" />
        <IF label="Départ N°1"    value={G.depart1}    onChange={v=>ug("depart1",v)} />
        <IF label="Départ N°2"    value={G.depart2}    onChange={v=>ug("depart2",v)} />
        <IF label="Date"          value={G.date}       onChange={v=>ug("date",v)} />
        <IF label="Fiche N°"      value={G.ficheNo}    onChange={v=>ug("ficheNo",v)} />
        <IF label="Élaboré par"   value={G.elaborePar} onChange={v=>ug("elaborePar",v)} />
        <IF label="Référence doc" value={G.refDoc}     onChange={v=>ug("refDoc",v)} />
        <IF label="Indice"        value={G.indice}     onChange={v=>ug("indice",v)} />
      </Card>

      <div className="space-y-4">
        <Card>
          <ST>Résumé des Calculs</ST>
          <div className="grid grid-cols-2 gap-3">
            <Stat label="Longueur Totale"    value={C.Lt}    unit="km" sub={`${segs.length} segment(s)`} color="cyan" />
            <Stat label="Z Primaire Total"   value={C.Zt}    unit="Ω"  sub={`∠ ${C.ang}°`} color="amber" />
            <Stat label="R Total (Ω)"        value={C.Rt}    unit="Ω"  color="slate" />
            <Stat label="X Total (Ω)"        value={C.Xt}    unit="Ω"  color="slate" />
            <Stat label="Impédance Vue (Zd)" value={C.Zd}    unit="Ω"  sub={`CT/VT = ${C.ctr}/${C.vtr}`} color="green" />
            <Stat label="Angle de Ligne"     value={C.ang}   unit="°"  sub="arctan(X/R)" color="cyan" />
          </div>
        </Card>

        <Card>
          <ST>Zones de Protection (Résumé)</ST>
          <table className="w-full">
            <thead>
              <tr className="text-xs text-slate-500 border-b border-slate-700">
                <th className="text-left pb-2 px-1">Zone</th>
                <th className="text-right pb-2 px-1">Portée (Ω)</th>
                <th className="text-right pb-2 px-1">%Zd</th>
                <th className="text-right pb-2 px-1">Tempo</th>
              </tr>
            </thead>
            <tbody>
              {[
                { z:"Z1", v:C.z1,      pct:zp.z1_pct, t:`${zp.tZ1} ms` },
                { z:"Z2", v:C.z2,      pct:zp.z2_pct, t:`${zp.tZ2} ms` },
                { z:"Zp", v:C.zPilote, pct:zp.zp_pct, t:`${round(pf(zp.tZp)/1000,1)} s` },
                { z:"Z3", v:C.z3,      pct:zp.z3_pct, t:`${round(pf(zp.tZ3)/1000,1)} s` },
                { z:"Z4↩",v:C.z4,      pct:zp.z4_pct, t:`${round(pf(zp.tZ4)/1000,1)} s` },
              ].map(row => (
                <tr key={row.z} className="border-b border-slate-800 hover:bg-slate-800/40">
                  <td className="py-1.5 px-1 text-xs font-mono text-amber-400 font-bold">{row.z}</td>
                  <td className="py-1.5 px-1 text-xs font-mono text-right text-slate-100">{row.v} Ω</td>
                  <td className="py-1.5 px-1 text-xs text-right text-slate-500">{row.pct}%</td>
                  <td className="py-1.5 px-1 text-xs text-right text-slate-500">{row.t}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>

        <Card>
          <ST>Protections Installées sur le Départ</ST>
          <table className="w-full text-xs">
            <thead><tr className="text-slate-500 border-b border-slate-700 text-left">
              <th className="pb-1 px-1">Protection</th><th className="pb-1 px-1">Code</th><th className="pb-1 px-1">Type</th>
            </tr></thead>
            <tbody>
              {[
                ["Protection distance N°1","[21]-1","D60 · GE"],
                ["Protection distance N°2","[21]-2","P442 · Alstom"],
                ["Directionnelle terre","[32N]","P442"],
                ["Protection Diff. ligne","[87L]","—"],
                ["Protection Max. U","[59]","D60"],
                ["Protection Min. U","[27]","—"],
                ["Réenclencheur","[79]","P142 · Alstom"],
                ["Contrôle synchronisme","[25]","D25/P442"],
                ["Défaillance disjoncteur","[50BF]","DBF + P142"],
                ["Diff. Barres","[87B]","—"],
              ].map(([n,c,t],i)=>(
                <tr key={i} className="border-b border-slate-800 hover:bg-slate-800/30">
                  <td className="py-1 px-1 text-slate-300">{n}</td>
                  <td className="py-1 px-1 font-mono text-amber-400">{c}</td>
                  <td className="py-1 px-1 text-slate-500">{t}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>
    </div>
  );

  /* ══════════════════════════════════════════
     TAB 1 – LIGNE
  ══════════════════════════════════════════ */
  const tabLigne = (
    <Card>
      <ST>Segments de la Ligne</ST>
      <div className="overflow-x-auto">
        <table className="w-full text-xs min-w-max">
          <thead>
            <tr className="text-slate-400 border-b border-slate-700">
              {["Nom du segment","Alliage","Section mm²","Long. km","R Ω/km","X Ω/km","Z Ω/km","R Ω","X Ω","Z Ω",""].map((h,i)=>(
                <th key={i} className={`pb-2 px-2 font-medium ${i>5?"text-right":"text-left"}`}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {C.segC.map(seg => (
              <tr key={seg.id} className="border-b border-slate-800 hover:bg-slate-800/30">
                {[
                  {k:"name",   w:176, num:false},
                  {k:"alloy",  w:80,  num:false},
                  {k:"section",w:64,  num:true},
                  {k:"length", w:88,  num:true},
                  {k:"r_km",   w:80,  num:true},
                  {k:"x_km",   w:80,  num:true},
                ].map(({k,w,num})=>(
                  <td key={k} className="py-1.5 px-2">
                    <input value={seg[k]} type={num?"number":"text"}
                      onChange={e=>us(seg.id,k,e.target.value)}
                      className={`bg-slate-800 border border-slate-700 rounded px-2 py-1 text-slate-100 focus:border-amber-400 outline-none ${num?"text-right":""}`}
                      style={{width:w}} />
                  </td>
                ))}
                <td className="py-1.5 px-2 text-right font-mono text-slate-500">{seg.z_km}</td>
                <td className="py-1.5 px-2 text-right font-mono text-cyan-400 font-semibold">{seg.R}</td>
                <td className="py-1.5 px-2 text-right font-mono text-cyan-400 font-semibold">{seg.X}</td>
                <td className="py-1.5 px-2 text-right font-mono text-amber-400 font-bold">{seg.Z}</td>
                <td className="py-1.5 px-2">
                  <button onClick={()=>delSeg(seg.id)} className="text-rose-500 hover:text-rose-300 text-base px-1">×</button>
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr className="border-t-2 border-amber-500/50 bg-amber-500/5">
              <td colSpan={3} className="py-2 px-2 font-bold text-amber-300 text-xs">TOTAL = {C.Lt} km</td>
              <td /><td /><td />
              <td className="px-2 text-right text-xs text-slate-500 font-mono">—</td>
              <td className="py-2 px-2 text-right font-mono font-bold text-amber-300">{C.Rt}</td>
              <td className="py-2 px-2 text-right font-mono font-bold text-amber-300">{C.Xt}</td>
              <td className="py-2 px-2 text-right font-mono font-bold text-amber-300">{C.Zt}</td>
              <td />
            </tr>
          </tfoot>
        </table>
      </div>
      <button onClick={addSeg}
        className="mt-4 px-4 py-2 bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs rounded-lg hover:bg-amber-500/30 transition-colors">
        + Ajouter un segment
      </button>
    </Card>
  );

  /* ══════════════════════════════════════════
     TAB 2 – RÉDUCTEURS
  ══════════════════════════════════════════ */
  const tabReducteurs = (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
      <Card>
        <ST>Transformateur de Tension (TT)</ST>
        <IF label="Primaire (V)"    value={red.vt_prim} onChange={v=>ur("vt_prim",v)} type="number" unit="V" />
        <IF label="Secondaire (V)"  value={red.vt_sec}  onChange={v=>ur("vt_sec",v)}  type="number" unit="V" />
        <IF label="Rapport TT"      value={`${C.vtr} : 1`} readOnly />
        <IF label="VT phase-neutre" value={`${C.vt_sec_ph} V`} readOnly hint="= Vsec/√3" />
        <div className="mt-3 p-3 bg-slate-800 rounded-lg border border-slate-700">
          <p className="text-xs text-slate-500">Configuration</p>
          <p className="text-sm font-mono text-amber-300 mt-1">{red.vt_prim}/√3 ÷ {red.vt_sec}/√3 V</p>
        </div>
      </Card>
      <Card>
        <ST>Transformateur de Courant (TC)</ST>
        <IF label="Primaire (A)"    value={red.ct_prim} onChange={v=>ur("ct_prim",v)} type="number" unit="A" />
        <IF label="Secondaire (A)"  value={red.ct_sec}  onChange={v=>ur("ct_sec",v)}  type="number" unit="A" />
        <IF label="Rapport TC"      value={`${C.ctr} / 1`} readOnly />
        <div className="mt-3 p-3 bg-slate-800 rounded-lg border border-slate-700">
          <p className="text-xs text-slate-500">Rapport TC/TT</p>
          <p className="text-sm font-mono text-amber-300 mt-1">{C.ctr} / {C.vtr} = {C.cv}</p>
        </div>
      </Card>
      <Card className="lg:col-span-2">
        <ST>Facteur de Conversion & Impédance Vue</ST>
        <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700 mb-4 font-mono text-xs text-slate-400">
          Z_sec = Z_prim × (TC / TT) = Z_prim × ({C.ctr} / {C.vtr}) = Z_prim × <span className="text-amber-400">{C.cv}</span>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Stat label="Facteur Conversion" value={C.cv}    sub="TC/TT" color="amber" />
          <Stat label="Impédance Vue Zd"   value={C.Zd}    unit="Ω" sub={`${C.Zt} × ${C.cv}`} color="green" />
          <Stat label="Z0 homopolaire"     value={C.Z0d}   unit="Ω" sub={`kZ=${C.kz}`} color="cyan" />
          <Stat label="Angle de Ligne"     value={C.ang}   unit="°" sub="arctan(X/R)" color="slate" />
        </div>
      </Card>
    </div>
  );

  /* ══════════════════════════════════════════
     TAB 3 – ZONES
  ══════════════════════════════════════════ */
  const tabZones = (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
      <Card>
        <ST>Portée des Zones (%Zd)</ST>
        <IF label="Zone 1 (%)"        value={zp.z1_pct} onChange={v=>uz("z1_pct",v)} type="number" unit="%" hint="Sous-portée" />
        <IF label="Zone 2 (%)"        value={zp.z2_pct} onChange={v=>uz("z2_pct",v)} type="number" unit="%" hint="Sur-portée" />
        <IF label="Zone 3 (%)"        value={zp.z3_pct} onChange={v=>uz("z3_pct",v)} type="number" unit="%" hint="Sauvegarde" />
        <IF label="Zone 4 Retour (%)" value={zp.z4_pct} onChange={v=>uz("z4_pct",v)} type="number" unit="%" hint="Arrière" />
        <IF label="Zone P Pilote (%)" value={zp.zp_pct} onChange={v=>uz("zp_pct",v)} type="number" unit="%" hint="Sur-portée pilote" />
        <ST>Compensation Homopolaire</ST>
        <IF label="Facteur kZ"        value={zp.kz}     onChange={v=>uz("kz",v)}     type="number" hint="Z0≈3Z1 → 0.67" />
        <IF label="Argument kZ (°)"   value={zp.kz_arg} onChange={v=>uz("kz_arg",v)} type="number" unit="°" />
        <p className="text-xs text-slate-500 mt-2 p-2 bg-slate-800 rounded border border-slate-700 font-mono">
          kZ = (Z0−Z1)/(3·Z1) &nbsp;|&nbsp; Z0 prim = {C.Z0} Ω &nbsp;|&nbsp; Z0d = {C.Z0d} Ω
        </p>
      </Card>
      <Card>
        <ST>Temporisations</ST>
        <IF label="tZ1 (ms)" value={zp.tZ1} onChange={v=>uz("tZ1",v)} type="number" unit="ms" />
        <IF label="tZ2 (ms)" value={zp.tZ2} onChange={v=>uz("tZ2",v)} type="number" unit="ms" />
        <IF label="tZ3 (ms)" value={zp.tZ3} onChange={v=>uz("tZ3",v)} type="number" unit="ms" />
        <IF label="tZ4 (ms)" value={zp.tZ4} onChange={v=>uz("tZ4",v)} type="number" unit="ms" />
        <IF label="tZp (ms)" value={zp.tZp} onChange={v=>uz("tZp",v)} type="number" unit="ms" />
        <ST>Portées Résistives (Quadrilatère)</ST>
        <IF label="Facteur R_G (× Z3)"  value={zp.r1g_factor}  onChange={v=>uz("r1g_factor",v)}  type="number" />
        <IF label="Facteur R_Ph (× Z3)" value={zp.r1ph_factor} onChange={v=>uz("r1ph_factor",v)} type="number" />
        <p className="text-xs text-slate-500 mt-2 font-mono p-2 bg-slate-800 rounded border border-slate-700">
          R1G = {C.r1g} Ω &nbsp;|&nbsp; R1Ph = {C.r1ph} Ω
        </p>
      </Card>
      <Card className="lg:col-span-2">
        <ST>Tableau des Zones Calculées</ST>
        <ZoneTable
          zones={["Z1","Z2","Z3","Z4 (Arr.)","Zp"]}
          rows={[
            { lbl:"Portée (Ω)",    vals:[C.z1, C.z2, C.z3, C.z4, C.zPilote], bold:true, hi:true },
            { lbl:"% de Zd",       vals:[zp.z1_pct+"%", zp.z2_pct+"%", zp.z3_pct+"%", zp.z4_pct+"%", zp.zp_pct+"%"] },
            { lbl:"Comp res kZ",   vals:[C.kz, C.kz, C.kz, C.kz, C.kz] },
            { lbl:"Argument kZ",   vals:["0°","0°","0°","0°","0°"] },
            { lbl:"R_G (Ω)",       vals:[C.r1g, C.r1g, C.r1g, C.r1g, C.r1g] },
            { lbl:"R_Ph (Ω)",      vals:[C.r1ph, C.r1ph, C.r1ph, C.r1ph, C.r1ph] },
            { lbl:"Temporisation", vals:[zp.tZ1+" ms", zp.tZ2+" ms", round(pf(zp.tZ3)/1000,1)+" s", round(pf(zp.tZ4)/1000,1)+" s", round(pf(zp.tZp)/1000,1)+" s"], bold:true },
            { lbl:"Direction",     vals:["Avant","Avant","Avant","Arrière","Aval"] },
          ]}
        />
      </Card>
    </div>
  );

  /* ══════════════════════════════════════════
     TAB 4 – P444
  ══════════════════════════════════════════ */
  const tabP444 = (
    <div className="space-y-4">
      <RelayHeader code="P444" name="ALSTOM / GE" color="blue"
        poste={G.poste} tension={G.tension} dep1={G.depart1} dep2={G.depart2} date={G.date} />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <STable title="Caractéristique de la Ligne" accent="blue">
          {C.segC.map((seg,i)=><>
            <SR key={`ca${i}`} label={`Alliage – Seg.${i+1}`} value={`${seg.alloy} ${seg.section} mm²`} />
            <SR key={`cl${i}`} label={`Longueur – Seg.${i+1}`} value={`${seg.length} km`} />
            <SR key={`cr${i}`} label={`R Total – Seg.${i+1}`}  value={`${seg.R} Ω`} />
            <SR key={`cx${i}`} label={`X Total – Seg.${i+1}`}  value={`${seg.X} Ω`} />
          </>)}
          <SR label="Longueur TOTALE" value={`${C.Lt} km`}  bold />
          <SR label="R = "            value={`${C.Rt} Ω`}   bold />
          <SR label="X = "            value={`${C.Xt} Ω`}   bold />
          <SR label="Z = "            value={`${C.Zt} Ω`}   bold />
        </STable>
        <div>
          <STable title="Réducteurs" accent="blue">
            <SR label="Rapport TT" value={`${red.vt_prim}/√3 / ${red.vt_sec}/√3 V`} bold />
            <SR label="Rapport TC" value={`${red.ct_prim} / ${red.ct_sec} A`}        bold />
          </STable>
          <STable title="Paramètres Ligne" accent="blue">
            <SR label="Longueur ligne" value={`${C.Lt} km`}   bold />
            <SR label="Impédance Zd"   value={`${C.Zd} Ω`}    bold highlight />
            <SR label="Argument ligne" value={`${C.ang}°`}    bold />
          </STable>
        </div>
      </div>

      <ZoneTable
        zones={["Z1","Z2","Z3","Z4","Zp"]}
        rows={[
          { lbl:"Comp res kZ",   vals:[C.kz,C.kz,C.kz,C.kz,C.kz] },
          { lbl:"Argument kZ",   vals:["0°","0°","0°","0°","0°"] },
          { lbl:"Portée (Ω)",    vals:[C.z1, C.z2, C.z3, C.z4, C.zPilote], bold:true, hi:true },
          { lbl:"RG Ω/L",        vals:[C.r1g,C.r1g,C.r1g,C.r1g,C.r1g] },
          { lbl:"RPh Ω/L",       vals:[C.r1ph,C.r1ph,C.r1ph,C.r1ph,C.r1ph] },
          { lbl:"Temporisation", vals:[zp.tZ1+" ms", zp.tZ2+" ms", round(pf(zp.tZ3)/1000,1)+" s", round(pf(zp.tZ4)/1000,1)+" s", round(pf(zp.tZp)/1000,1)+" s"], bold:true },
          { lbl:"Direction",     vals:["Avant","Avant","Avant","Arrière","Aval"] },
        ]}
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <STable title="Configuration" accent="slate">
          <SR label="Groupe réglages actifs"         value="Groupe 1"               bold />
          <SR label="Protection distance"            value="Activé"                 bold />
          <SR label="Détection pompage"              value="Activé"                 bold />
          <SR label="Protection ampèremétrique"      value="Désactivé" />
          <SR label="Rupture conducteur"             value="Activé"                 bold />
          <SR label="Protection défaut terre"        value="Puissance wattmétrique" bold />
          <SR label="Comparaison directionnelle DEF" value="Désactivé" />
          <SR label="Supervision"                    value="Activé"                 bold />
          <SR label="Contrôle tension"               value="Activé"                 bold />
          <SR label="Réenclencheur"                  value="Activé"                 bold />
          <SR label="Surcharge thermique"            value="Désactivé" />
          <SR label="Défaillance disjoncteur"        value="Désactivé" />
        </STable>
        <div>
          <STable title="Logique Distance" accent="slate">
            <SR label="Mode standard"        value="P.R.A.Z2"                  bold highlight />
            <SR label="Type de défaut"        value="Tout type de défaut" />
            <SR label="Mode déclenchement"   value="Mono Z1Z2 et réception TA" bold />
            <SR label="tInvCourantDéf"       value="60 ms" />
            <SR label="Réencl. Z1 activée"  value="1" bold />
            <SR label="Réencl. Z2 activée"  value="1" bold />
            <SR label="Réencl. TAC"         value="1" bold />
            <SR label="Encl. toutes zones"  value="1" bold />
          </STable>
          <STable title="Détection de Pompage" accent="slate">
            <SR label="Delta R" value={`${C.blinder} Ω`} bold highlight />
            <SR label="Delta X" value={`${C.blinder} Ω`} bold highlight />
            <SR label="IN > (%max)"      value="20 %" />
            <SR label="Ii > (%max)"      value="20 %" />
            <SR label="Imax line>"       value="2 A" />
            <SR label="Tempo déverrouil" value="5 s" />
            <SR label="Zones bloquées"   value="111111" />
          </STable>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <STable title="Réenclencheur" accent="slate">
          <SR label="Mode monophasé"           value="1"       bold />
          <SR label="Mode triphasé"            value="N.A" />
          <SR label="Tempo 1er cycle M"        value="1,5 sec" bold />
          <SR label="Temporisation de blocage" value="60 sec"  bold />
          <SR label="Tps ordre fermeture"      value="0,1 s"   bold />
        </STable>
        <STable title="Supervision TT" accent="slate">
          <SR label="Temporisation FF"    value="10 sec" />
          <SR label="Deverr FF / Ii, I0"  value="0,2 A"  bold />
          <SR label="FF triphasé"         value="Activé" bold />
          <SR label="Seuil 3P"            value="12 V"   />
          <SR label="Delta I>"            value="0,2 A"  bold />
        </STable>
        <STable title="Contrôle de Système" accent="slate">
          <SR label="Ligne morte V<"   value="12 V"   />
          <SR label="Ligne vive V>"    value="46 V"   bold />
          <SR label="Barre morte V<"   value="12 V"   />
          <SR label="Barre vive V>"    value="46 V"   bold />
          <SR label="Tension diff."    value="12 V"   />
          <SR label="Fréquence diff."  value="0,1 Hz" bold />
          <SR label="Phase diff."      value="20 °"   bold />
          <SR label="Tempo barre-ligne" value="0,5 sec" />
        </STable>
      </div>
    </div>
  );

  /* ══════════════════════════════════════════
     TAB 5 – D60
  ══════════════════════════════════════════ */
  const tabD60 = (
    <div className="space-y-4">
      <RelayHeader code="D60" name="GE MULTILIN" color="green"
        poste={G.poste} tension={G.tension} dep1={G.depart1} dep2={G.depart2} date={G.date} />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <STable title="Configuration Système – Courant" accent="green">
          <SR label="Prim. TC phase"   value={`${red.ct_prim} A`}   bold />
          <SR label="Sec. TC phase"    value={`${red.ct_sec} A`}    bold />
          <SR label="Prim. TC terre"   value={`${red.ct_prim} A`}   bold />
          <SR label="Sec. TC terre"    value={`${red.ct_sec} A`}    bold />
        </STable>
        <STable title="Configuration Système – Tension" accent="green">
          <SR label="Sec. TT phase"    value={`${C.vt_sec_ph} V`}  />
          <SR label="Rapport TT phase" value={`${C.vtr}:1`}        bold />
          <SR label="Sec. TT aux."     value={`${C.vt_sec_ph} V`}  />
          <SR label="Rapport TT aux."  value={`${C.vtr}:1`}        bold />
        </STable>
        <STable title="Ligne" accent="green">
          <SR label="Amplitude Z directe"      value={`${C.Zd} Ω`}   bold highlight />
          <SR label="Angle Z directe"          value={`${C.ang}°`}   bold />
          <SR label="Amplitude Z homopolaire"  value={`${C.Z0d} Ω`}  bold />
          <SR label="Angle Z homopolaire"      value={`${C.ang}°`}   />
          <SR label="Longueur de ligne"        value={`${C.Lt} km`}  bold />
        </STable>
        <STable title="Amorçage de Ligne" accent="green">
          <SR label="Fonction"                 value="Activée"      bold />
          <SR label="Source du signal"         value="Ligne (src 1)" />
          <SR label="Surintensité inst."       value="1,500 pu"     bold />
          <SR label="Amorçage sous-tension"    value="0,200 pu"     />
          <SR label="Tempo. extr. ouverte"     value="65,535 s"     />
        </STable>
      </div>

      {["Phase","Terre"].map(type => (
        <div key={type}>
          <ZoneTable
            zones={["Z1","Z2","Z3 (Zp)","Z4","Z5 (Z3bkp)"]}
            accentColor="green"
            rows={[
              { lbl:"Direction",     vals:["Avant","Avant","Avant","Arrière","Avant"] },
              { lbl:"Portée (Ω)",    vals:[C.z1, C.z2, C.zPilote, C.z4, C.z3], bold:true, hi:true },
              ...(type==="Terre"?[
                { lbl:"Amplitude Z0/Z1",  vals:["3","3","3","3","3"] },
                { lbl:"Angle Z0/Z1",      vals:["0,24°","0,24°","0,24°","0,24°","0,24°"] },
              ]:[]),
              { lbl:"ACR (°)",       vals:[`${C.ang}°`,`${C.ang}°`,`${C.ang}°`,`${C.ang}°`,`${C.ang}°`] },
              { lbl:"Volet Qd (Ω)", vals:[C.blinder,C.blinder,C.blinder,C.blinder,C.blinder] },
              { lbl:"Temporisation", vals:["0 s","0,400 s","1,000 s","3,200 s","3,200 s"], bold:true },
            ]}
          />
        </div>
      ))}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <STable title="Détection Pendulaison" accent="green">
          <SR label="Fonction"              value="Activé"          bold />
          <SR label="Mode"                  value="2 niveaux" />
          <SR label="Portée avant"          value={`${C.porteeAv} Ω`}   bold highlight />
          <SR label="Portée arrière"        value={`${C.porteeArr} Ω`}  bold />
          <SR label="ACR avant/arrière"     value={`${C.ang}°`} />
          <SR label="Angle limite externe"  value="120°" />
          <SR label="Angle limite moyen"    value="90°" />
          <SR label="Angle limite interne"  value="60°" />
          <SR label="Amorçage tempo 1"      value="0,030 s" />
          <SR label="Amorçage tempo 2"      value="0,017 s" />
          <SR label="Mode déclenchement"    value="Tôt" bold />
        </STable>
        <div>
          <STable title="Surtension de Phase (59)" accent="green">
            <SR label="Fonction"             value="Activé"     bold />
            <SR label="Source"               value="Ligne (Src 1)" />
            <SR label="Amorçage"             value="1,250 pu"   bold highlight />
            <SR label="Temporisation"        value="30 s Déclt" bold highlight />
            <SR label="Tempo de rappel"      value="0 s" />
          </STable>
          <STable title="Panne de Fusible TT" accent="green">
            <SR label="Fonction"             value="Active"         bold />
            <SR label="Mode prog. pilotes"   value="Activé (TDPSD mono)" bold />
            <SR label="Tempo auto-maintien"  value="0,200 s" />
            <SR label="Bits communication"   value="1" />
            <SR label="Rx1"                  value="TD_Rx_MONO_En"  bold />
          </STable>
        </div>
      </div>
    </div>
  );

  /* ══════════════════════════════════════════
     TAB 6 – DBF (50BF hardware standalone)
  ══════════════════════════════════════════ */
  const tabDBF = (
    <div className="space-y-4">
      <RelayHeader code="DBF" name="Défaillance Disjoncteur – Relais Dédié" color="orange"
        poste={G.poste} tension={G.tension} dep1={G.depart1} dep2={G.depart2} date={G.date} />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <STable title="1. Réglages Généraux (T0)" accent="orange">
          <SR label="État du Relais"     value="En service"        bold />
          <SR label="Filiation"          value="Sans filiation" />
          <SR label="Fréquence"          value="50 Hz" />
          <SR label="Rapport TC PH."     value={`${red.ct_prim} (${red.ct_prim}/${red.ct_sec})`} bold />
          <SR label="Rapport TC NEUT."   value="N.A" />
        </STable>
        <STable title="2. Table Active (T0)" accent="orange">
          <SR label="Table active"       value="1"                 bold />
        </STable>
        <STable title="3. Autorisation de Fonctionnement (T0)" accent="orange">
          <SR label="Fonction 50BF 1P"  value="Permis"            bold />
          <SR label="Fonction 50BF 3P"  value="Permis"            bold />
          <SR label="Fonc.3P Sans COU"  value="Interdit" />
        </STable>
        <STable title="4. Fonction 50BF (T1)" accent="orange">
          <SR label="Démarrage 50BF H"  value="0,2 A"             bold highlight />
          <SR label="Démarrage 50BF B"  value="0,2 A"             bold highlight />
          <SR label="t Monophasé T1"    value="60 ms (deux bob.)"  bold />
          <SR label="t 3P avec I T2"    value="60 ms (deux bob.)"  bold />
          <SR label="t 3P sans I T3"    value="Non utilisé" />
          <SR label="t Deuxième Éch."   value="200 ms (encadrants)" bold />
        </STable>
      </div>
    </div>
  );

  /* ══════════════════════════════════════════
     TAB 7 – D25 SYNCHROCHEK
  ══════════════════════════════════════════ */
  const tabD25 = (
    <div className="space-y-4">
      <RelayHeader code="D25" name="SYNCHROCHEK – Contrôle de Synchronisme" color="purple"
        poste={G.poste} tension={G.tension} dep1={G.depart1} dep2={G.depart2} date={G.date} />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <STable title="Caractéristique de la Ligne" accent="purple">
          {C.segC.map((seg,i)=><>
            <SR key={`da${i}`} label={`Alliage – Seg.${i+1}`} value={`${seg.alloy} ${seg.section} mm²`} />
            <SR key={`dl${i}`} label={`Longueur – Seg.${i+1}`} value={`${seg.length} km`} />
            <SR key={`dr${i}`} label={`R – Seg.${i+1}`} value={`${seg.R} Ω`} />
            <SR key={`dx${i}`} label={`X – Seg.${i+1}`} value={`${seg.X} Ω`} />
          </>)}
          <SR label="Total = " value={`${C.Lt} km`} bold />
          <SR label="R Total" value={`${C.Rt} Ω`}   bold />
          <SR label="X Total" value={`${C.Xt} Ω`}   bold />
          <SR label="Z Total" value={`${C.Zt} Ω`}   bold />
        </STable>
        <div>
          <STable title="Réducteurs" accent="purple">
            <SR label="Rapport TT" value={`${red.vt_prim}V/√3 / ${red.vt_sec}V/√3`} bold />
            <SR label="Rapport TC" value={`${red.ct_prim} / ${red.ct_sec} A`}        bold />
          </STable>
          <STable title="Contrôleur F25 – Réglage Général" accent="purple">
            <SR label="CSS Ratio TT"          value={`${C.vtr}:1`} bold highlight />
            <SR label="CSS Déphasage réseau"  value="20 deg"       bold />
            <SR label="CSS Glis. fréq. réseau" value="100 mHz"     bold />
            <SR label="CSS Tempo réseau"      value="0,5 s"        bold />
            <SR label="CSS Tension vive B/L"  value="46 V"         bold />
            <SR label="CSS Tension morte B/L" value="12 V"         bold />
          </STable>
        </div>
      </div>
    </div>
  );

  /* ══════════════════════════════════════════
     TAB 8 – P142 (50BF + 79 + overcurrent)
  ══════════════════════════════════════════ */
  const tabP142 = (
    <div className="space-y-4">
      <RelayHeader code="P142" name="ALSTOM – Défaillance Disjoncteur + Réenclencheur" color="red"
        poste={G.poste} tension={G.tension} dep1={G.depart1} dep2={G.depart2} date={G.date} />

      {/* ── Paramètres saisie ── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 no-print">
        <Card>
          <ST>Données Entrée – 50BF</ST>
          <IF label="I démarrage phase (A sec)" value={p142.bf_i_phase}  onChange={v=>up1("bf_i_phase",v)}  type="number" unit="A" hint={`→ ${C.bf_ih} A prim`} />
          <IF label="I démarrage neutre (A sec)" value={p142.bf_i_neutre} onChange={v=>up1("bf_i_neutre",v)} type="number" unit="A" />
          <IF label="t1 Temp. réencl. (ms)"     value={p142.bf_t1}       onChange={v=>up1("bf_t1",v)}       type="number" unit="ms" />
          <IF label="t2 Temp. CB (ms)"          value={p142.bf_t2}       onChange={v=>up1("bf_t2",v)}       type="number" unit="ms" />
          <IF label="t3 Temp. CBF2 (ms)"        value={p142.bf_t3}       onChange={v=>up1("bf_t3",v)}       type="number" unit="ms" />
          <IF label="t Reset (ms)"              value={p142.bf_t_reset}  onChange={v=>up1("bf_t_reset",v)}  type="number" unit="ms" />
        </Card>
        <Card>
          <ST>Données Entrée – 50/51 Max. Courant</ST>
          <IF label="I instantané (% In)"       value={p142.i_inst_pct}  onChange={v=>up1("i_inst_pct",v)}  type="number" unit="%" hint={`→ ${C.i_inst} A prim`} />
          <IF label="I temporisé (% In)"        value={p142.i_def_pct}   onChange={v=>up1("i_def_pct",v)}   type="number" unit="%" hint={`→ ${C.i_def} A prim`} />
          <IF label="Temporisation (s)"         value={p142.t_def}       onChange={v=>up1("t_def",v)}       type="number" unit="s" />
          <ST>67N – Directionnelle Terre</ST>
          <IF label="I0 seuil (A sec)"          value={p142.dir67n_i0}   onChange={v=>up1("dir67n_i0",v)}   type="number" unit="A" />
          <IF label="Temporisation (s)"         value={p142.dir67n_t}    onChange={v=>up1("dir67n_t",v)}    type="number" unit="s" />
          <IF label="Angle direction (°)"       value={p142.dir67n_angle} onChange={v=>up1("dir67n_angle",v)} type="number" unit="°" />
        </Card>
        <Card>
          <ST>Données Entrée – 79 Réenclencheur</ST>
          <IF label="Mode (1=mono, 3=tri)"      value={p142.r79_mode}    onChange={v=>up1("r79_mode",v)}    type="number" />
          <IF label="t mort cycle 1 (s)"        value={p142.r79_t_dead1} onChange={v=>up1("r79_t_dead1",v)} type="number" unit="s" />
          <IF label="t mort cycle 2 (s)"        value={p142.r79_t_dead2} onChange={v=>up1("r79_t_dead2",v)} type="number" unit="s" />
          <IF label="t récupération (s)"        value={p142.r79_t_rec}   onChange={v=>up1("r79_t_rec",v)}   type="number" unit="s" />
          <IF label="Nombre de cycles"          value={p142.r79_n_cycles} onChange={v=>up1("r79_n_cycles",v)} type="number" />
          <ST>59N – Surtension Homopolaire</ST>
          <IF label="U0 seuil (V)"              value={p142.u0_seuil}    onChange={v=>up1("u0_seuil",v)}    type="number" unit="V" />
          <IF label="Temporisation (s)"         value={p142.u0_t}        onChange={v=>up1("u0_t",v)}        type="number" unit="s" />
        </Card>
      </div>

      {/* ── Fiche de Réglage Output ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

        {/* ── Bloc Identité ── */}
        <STable title="Identification" accent="red">
          <SR label="Poste"        value={G.poste}              bold />
          <SR label="Départ"       value={`${G.tension} kV N°: ${G.depart1} + ${G.depart2}`} bold />
          <SR label="Référence"    value={G.refDoc} />
          <SR label="Indice"       value={G.indice} />
          <SR label="Élaboré par"  value={G.elaborePar} />
          <SR label="Date"         value={G.date} />
        </STable>

        {/* ── Réducteurs ── */}
        <STable title="Réducteurs" accent="red">
          <SR label="Rapport TT" value={`${red.vt_prim}/√3 / ${red.vt_sec}/√3 V`} bold />
          <SR label="Rapport TC phase"  value={`${red.ct_prim} / ${red.ct_sec} A`} bold />
          <SR label="Rapport TC neutre" value={`${red.ct_prim} / ${red.ct_sec} A`} bold />
          <SR label="Fréquence"         value="50 Hz" />
          <SR label="Courant nominal In" value={`${p142.in_nom} A (secondaire)`}   bold />
        </STable>

        {/* ── 50BF ── */}
        <STable title="Fonction 50BF – Défaillance Disjoncteur" accent="red">
          <SR label="Fonction 50BF"            value="Activée"            bold highlight />
          <SR label="Mode"                     value="1P + 3P"            bold />
          <SR label="I démarrage phase"        value={`${p142.bf_i_phase} A (sec) → ${C.bf_ih} A prim`} bold highlight />
          <SR label="I démarrage neutre"       value={`${p142.bf_i_neutre} A (sec)`} bold />
          <SR label="t1 – Tempo réenclenchement" value={`${p142.bf_t1} ms`}     bold />
          <SR label="t2 – Tempo CB défaillant"   value={`${p142.bf_t2} ms`}     bold highlight />
          <SR label="t3 – Tempo CBF2 (encadrant)" value={`${p142.bf_t3} ms`}   bold />
          <SR label="t Reset"                  value={`${p142.bf_t_reset} ms`}  />
          <SR label="Déclenchement"            value="Triphasé sur 2 bobines" bold />
          <SR label="Ordre vers jeux de barres" value="Activé – disj. adjacents" bold />
        </STable>

        {/* ── 50/51 Max I ── */}
        <STable title="Fonction 50/51 – Protection Surintensité" accent="red">
          <SR label="Fonction 50 (instantané)"  value="Activée"           bold />
          <SR label="Seuil I instantané"        value={`${p142.i_inst_pct}% × In = ${C.i_inst} A prim`} bold highlight />
          <SR label="Temporisation t50"         value="0 ms (instantané)" bold />
          <SR label="Fonction 51 (temporisée)"  value="Activée"           bold />
          <SR label="Seuil I temporisée"        value={`${p142.i_def_pct}% × In = ${C.i_def} A prim`}  bold highlight />
          <SR label="Temporisation t51"         value={`${p142.t_def} s`} bold />
          <SR label="Courbe"                    value="IDMT – Standard Inverse (SI)" />
          <SR label="Temporisation sécurité"    value="0,1 s" />
        </STable>

        {/* ── 67N ── */}
        <STable title="Fonction 67N – Directionnelle Terre" accent="red">
          <SR label="Fonction 67N"            value="Activée"              bold />
          <SR label="Direction"               value="Aval (vers réseau)"   bold />
          <SR label="Seuil I0"                value={`${p142.dir67n_i0} A (sec)`} bold highlight />
          <SR label="Angle direction"         value={`${p142.dir67n_angle}°`}    bold />
          <SR label="Polarisation"            value="Tension V0 ou I0"    />
          <SR label="Temporisation"           value={`${p142.dir67n_t} s`}       bold highlight />
          <SR label="Déclenchement"           value="Triphasé"            bold />
        </STable>

        {/* ── 59N ── */}
        <STable title="Fonction 59N – Surtension Homopolaire" accent="red">
          <SR label="Fonction 59N"            value="Activée"              bold />
          <SR label="Source"                  value="Tension résiduelle 3V0" />
          <SR label="Seuil U0"                value={`${p142.u0_seuil} V`}        bold highlight />
          <SR label="Temporisation"           value={`${p142.u0_t} s`}           bold />
          <SR label="Déclenchement"           value="Triphasé"            bold />
        </STable>

        {/* ── 79 ── */}
        <STable title="Fonction 79 – Réenclencheur Automatique" accent="red">
          <SR label="Fonction 79"             value="Activée"              bold />
          <SR label="Mode réenclenchement"    value={p142.r79_mode === "1" ? "Monophasé" : "Triphasé"} bold />
          <SR label="Nombre de cycles"        value={p142.r79_n_cycles}    bold />
          <SR label="t mort cycle 1"          value={`${p142.r79_t_dead1} s`} bold highlight />
          <SR label="t mort cycle 2"          value={`${p142.r79_t_dead2} s`} bold />
          <SR label="t récupération (blocage)" value={`${p142.r79_t_rec} s`} bold />
          <SR label="Verrouillage final"       value="Activé après dernier cycle" />
          <SR label="Condition enclenchement"  value="Contrôle synchro (D25)" />
        </STable>

        {/* ── TCS 74 ── */}
        <STable title="Fonction 74 – Supervision Circuit Déclenchement" accent="red">
          <SR label="Fonction TCS"            value="Activée"              bold />
          <SR label="Seuil courant bobine"    value={`${p142.tcs_i} A`}         bold highlight />
          <SR label="Temporisation alarme"    value={`${p142.tcs_t} s`}         bold />
          <SR label="Sortie"                  value="Alarme uniquement"   />
          <SR label="Supervision bobine 1"    value="Activée"             bold />
          <SR label="Supervision bobine 2"    value="Activée"             bold />
        </STable>

      </div>

      {/* ── Note de calcul ── */}
      <Card>
        <ST>Note de Calcul – Vérification des Seuils</ST>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-700 text-slate-400">
                <th className="text-left pb-2 px-2">Paramètre</th>
                <th className="text-right pb-2 px-2">Valeur Sec.</th>
                <th className="text-right pb-2 px-2">Valeur Prim.</th>
                <th className="text-right pb-2 px-2">% In</th>
                <th className="text-left pb-2 px-2 pl-4">Commentaire</th>
              </tr>
            </thead>
            <tbody>
              {[
                ["I démarrage 50BF phase", `${p142.bf_i_phase} A`, `${C.bf_ih} A`, `${round(pf(p142.bf_i_phase)*100,1)}%`, "≥ 0.1 In – sensibilité minimale"],
                ["I démarrage 50BF neutre",`${p142.bf_i_neutre} A`, `${round(pf(p142.bf_i_neutre)*C.ctr,1)} A`, `${round(pf(p142.bf_i_neutre)*100,1)}%`, "Idem phase"],
                ["Seuil 50 instantané",    `${round(pf(p142.i_inst_pct)/100,3)} pu`, `${C.i_inst} A`, `${p142.i_inst_pct}%`, "1.2–1.5 × In nominal"],
                ["Seuil 51 temporisé",     `${round(pf(p142.i_def_pct)/100,3)} pu`,  `${C.i_def} A`,  `${p142.i_def_pct}%`,  "1.05–1.2 × In nominal"],
                ["Seuil I0 67N",           `${p142.dir67n_i0} A`,  `${round(pf(p142.dir67n_i0)*C.ctr,1)} A`, "—", "5–10% In secondaire"],
                ["Rapport TC phase",       `1 A`,  `${red.ct_prim} A`, "—", `Rapport = ${C.ctr}`],
              ].map(([p,vs,vp,pc,c],i)=>(
                <tr key={i} className="border-b border-slate-800 hover:bg-slate-800/30">
                  <td className="py-1.5 px-2 text-slate-300 font-semibold">{p}</td>
                  <td className="py-1.5 px-2 text-right font-mono text-cyan-400">{vs}</td>
                  <td className="py-1.5 px-2 text-right font-mono text-amber-400">{vp}</td>
                  <td className="py-1.5 px-2 text-right font-mono text-slate-400">{pc}</td>
                  <td className="py-1.5 px-2 pl-4 text-slate-500 italic">{c}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );

  /* ══════════════════════════════════════════
     TABS CONFIG
  ══════════════════════════════════════════ */
  const TABS = [
    { id:0, label:"Général",     icon:"🏗",  content: tabGeneral },
    { id:1, label:"Ligne",       icon:"〰",  content: tabLigne },
    { id:2, label:"Réducteurs",  icon:"🔁",  content: tabReducteurs },
    { id:3, label:"Zones",       icon:"📐",  content: tabZones },
    { id:4, label:"P444",        icon:"🔵",  content: tabP444 },
    { id:5, label:"D60",         icon:"🟢",  content: tabD60 },
    { id:6, label:"DBF",         icon:"🟠",  content: tabDBF },
    { id:7, label:"D25",         icon:"🟣",  content: tabD25 },
    { id:8, label:"P142",        icon:"🔴",  content: tabP142 },
  ];

  /* ══════════════════════════════════════════
     RENDER
  ══════════════════════════════════════════ */
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      {/* ── Top Bar ── */}
      <div className="bg-slate-900 border-b border-slate-700 sticky top-0 z-50 no-print">
        <div className="max-w-screen-2xl mx-auto px-4 py-2.5 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-amber-400 rounded flex items-center justify-center text-slate-900 font-black text-sm flex-shrink-0">⚡</div>
            <div>
              <p className="text-xs font-bold text-slate-100 leading-none">Calcul Réglage des Protections</p>
              <p className="text-xs text-slate-500 leading-none mt-0.5">ONEE · Branche Électricité · DCT · Direction Opérateur Système</p>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-3 text-xs text-slate-500 font-mono">
            <span className="text-amber-400 font-semibold">{G.poste}</span>
            <span className="text-slate-700">|</span>
            <span>{G.tension} kV</span>
            <span className="text-slate-700">|</span>
            <span>Zd = <span className="text-green-400">{C.Zd} Ω</span></span>
            <span className="text-slate-700">|</span>
            <span>L = <span className="text-cyan-400">{C.Lt} km</span></span>
            <span className="text-slate-700">|</span>
            <span>∠ {C.ang}°</span>
          </div>
        </div>
      </div>

      {/* ── Tab Bar ── */}
      <div className="bg-slate-900 border-b border-slate-800 sticky top-12 z-40 no-print">
        <div className="max-w-screen-2xl mx-auto px-4">
          <div className="flex overflow-x-auto gap-0 scrollbar-none">
            {TABS.map(t => (
              <button key={t.id} onClick={() => setActiveTab(t.id)}
                className={`flex items-center gap-1.5 px-4 py-3 text-xs font-semibold whitespace-nowrap border-b-2 transition-all flex-shrink-0
                  ${activeTab === t.id
                    ? "border-amber-400 text-amber-400 bg-amber-400/5"
                    : "border-transparent text-slate-500 hover:text-slate-300 hover:bg-slate-800/50"
                  }`}>
                <span className="text-base leading-none">{t.icon}</span>
                <span>{t.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ── Page Content ── */}
      <div className="max-w-screen-2xl mx-auto px-4 py-5">
        {TABS[activeTab].content}
      </div>

      {/* ── Footer ── */}
      <footer className="border-t border-slate-800 bg-slate-900 mt-10 py-3">
        <div className="max-w-screen-2xl mx-auto px-4 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600 font-mono">
          <span>{G.refDoc} · Indice {G.indice} · Élaboré par : {G.elaborePar} · {G.date}</span>
          <span>Z1={C.z1}Ω · Z2={C.z2}Ω · Zp={C.zPilote}Ω · Z3={C.z3}Ω · Zd={C.Zd}Ω</span>
        </div>
      </footer>
    </div>
  );
}
