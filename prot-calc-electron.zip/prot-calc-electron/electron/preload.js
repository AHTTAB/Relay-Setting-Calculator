const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("electronAPI", {
  // Called by menu Ctrl+P → tells React to show #pdoc then window.print()
  onMenuPrint: (callback) => ipcRenderer.on("menu-print", callback),

  // Legacy: renderer can still signal print via IPC
  printReport: () => ipcRenderer.send("print-report"),

  platform: process.platform,
});
