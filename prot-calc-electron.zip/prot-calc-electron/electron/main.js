const { app, BrowserWindow, Menu, shell, dialog, ipcMain } = require("electron");
const path = require("path");

const isDev = process.env.NODE_ENV === "development" || !app.isPackaged;

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width:  1400,
    height: 860,
    minWidth:  900,
    minHeight: 620,
    icon: path.join(__dirname, "icon.ico"),
    title: "Protection Relay Calculator — ONEE",
    backgroundColor: "#020617",
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, "preload.js"),
      webSecurity: !isDev,
    },
    show: false,
  });

  if (isDev) {
    mainWindow.loadURL("http://localhost:5173");
    mainWindow.webContents.openDevTools({ mode: "detach" });
  } else {
    mainWindow.loadFile(path.join(__dirname, "../dist/index.html"));
  }

  mainWindow.once("ready-to-show", () => {
    mainWindow.show();
    mainWindow.focus();
  });

  mainWindow.on("closed", () => { mainWindow = null; });
}

function buildMenu() {
  const template = [
    {
      label: "Fichier",
      submenu: [
        {
          label: "🖨  Imprimer le Rapport (Ctrl+P)",
          accelerator: "CmdOrCtrl+P",
          click: () => {
            // Tell the React app to show #pdoc then print — do NOT call webContents.print() directly
            if (mainWindow) mainWindow.webContents.send("menu-print");
          },
        },
        { type: "separator" },
        { role: "quit", label: "Quitter" },
      ],
    },
    {
      label: "Affichage",
      submenu: [
        { role: "reload",           label: "Recharger" },
        { role: "toggleDevTools",   label: "Outils développeur" },
        { type: "separator" },
        { role: "resetZoom",        label: "Zoom normal" },
        { role: "zoomIn",           label: "Zoom +" },
        { role: "zoomOut",          label: "Zoom −" },
        { type: "separator" },
        { role: "togglefullscreen", label: "Plein écran" },
      ],
    },
    {
      label: "Aide",
      submenu: [
        {
          label: "À propos",
          click: () =>
            dialog.showMessageBox(mainWindow, {
              type: "info",
              title: "À propos",
              message: "Protection Relay Calculator",
              detail:
                "Version 1.0.0\n\nONEE — Branche Électricité\nPôle Industriel · Direction Centrale Transport\nDirection Opérateur Système\n\nCalcul de réglage des protections\nP444 · D60 · P142 · DBF · D25 · 7SA82 · REL670",
              buttons: ["OK"],
            }),
        },
      ],
    },
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

/* IPC — renderer asks to print (not needed anymore, kept for compatibility) */
ipcMain.on("print-report", () => {
  if (mainWindow) mainWindow.webContents.send("menu-print");
});

app.whenReady().then(() => {
  createWindow();
  buildMenu();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

app.on("web-contents-created", (_, contents) => {
  contents.on("will-navigate", (event, url) => {
    if (!isDev && !url.startsWith("file://")) event.preventDefault();
  });
});
