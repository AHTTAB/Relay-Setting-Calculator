# ⚡ Protection Relay Calculator — ONEE

Application bureau (Windows/Linux/Mac) pour le calcul de réglage  
des protections de lignes haute tension.

---

## 🖥️ Prérequis

| Outil | Version minimale | Lien |
|-------|-----------------|------|
| **Node.js** | 18.x LTS | https://nodejs.org |
| **npm** | inclus avec Node.js | — |
| **Git** | optionnel | — |

---

## 🚀 Construction de l'installateur .exe (Windows)

```bash
# 1. Installer les dépendances (une seule fois)
npm install

# 2. Construire + packager en .exe
npm run make-exe
```

L'installateur sera dans :
```
dist-exe/
  └── Protection Relay Calculator Setup 1.0.0.exe
```

---

## 🔧 Mode développement

```bash
npm install
npm run dev
```

Ceci lance simultanément le serveur Vite et la fenêtre Electron.

---

## 📦 Structure du projet

```
prot-calc-electron/
├── electron/
│   ├── main.js          ← Processus principal Electron
│   ├── preload.js       ← Bridge sécurisé (IPC)
│   └── icon.ico         ← Icône Windows
├── src/
│   ├── main.jsx         ← Entrée React
│   └── App.jsx          ← Application complète (1300+ lignes)
├── index.html
├── vite.config.js
├── package.json
├── tailwind.config.js
├── postcss.config.js
└── LICENSE.txt
```

---

## 📐 Fonctionnalités

| Onglet | Description |
|--------|-------------|
| Général | Infos départ, résumé calculs |
| Ligne | Câblothèque (ALMEC 570/366, AL/AC 288) + segments |
| Réducteurs | TC/TT, facteur de conversion |
| Zones | Z1–Z4, Zp, kZ, temporisations |
| P444 | Fiche Alstom/GE complète |
| D60 | Fiche GE Multilin complète |
| DBF | Défaillance disjoncteur |
| D25 | Synchrochek |
| P142 | 50BF + 79 + 50/51 + 67N + 59N + 74 |
| **7SA82** | Siemens (valeurs secondaires, Kr/Kx) |
| **REL 670** | ABB (valeurs primaires HT, RPSD, SOTF) |

**Impression** : Rapport PDF complet 10 pages A4 via le menu Fichier → Imprimer ou Ctrl+P.

---

## 🪲 Dépannage

| Problème | Solution |
|----------|---------|
| `electron-builder: command not found` | `npm install -g electron-builder` |
| Icône manquante | Exécuter `python3 generate_icon.py` |
| Erreur NSIS | Installer [NSIS](https://nsis.sourceforge.io/) |
| Fenêtre blanche | Vérifier que `dist/` existe après `npm run build` |

---

*ONEE — Branche Électricité — DCT — Direction Opérateur Système — 2025*
