import { useState, useMemo, useCallback, useEffect } from "react";

/* ══════════════════════════════════════════════
   CÂBLOTHÈQUE
══════════════════════════════════════════════ */
const CABLE_DB = {
  "ALMEC 570": { r_km: 0.0700, x_km: 0.3959, label: "ALMEC 570 mm²" },
  "ALMEC 366": { r_km: 0.0912, x_km: 0.4300, label: "ALMEC 366 mm²" },
  "ALAC 288":  { r_km: 0.1350, x_km: 0.4340, label: "AL/AC 288 mm²" },
  "Manuel":    { r_km: null,   x_km: null,   label: "Manuel" },
};

/* ══════════════════════════════════════════════
   UTILITIES
══════════════════════════════════════════════ */
const R  = (v, d=3) => isNaN(v) ? 0 : +v.toFixed(d);
const pf = (v, d=3) => R(parseFloat(v)||0, d);
const fd = v => (v===null||v===undefined) ? "—" : String(v);
const toDeg = r => r*180/Math.PI;

/* ══════════════════════════════════════════════
   PRINT CSS (injected as <style> in JSX)
══════════════════════════════════════════════ */
const PRINT_STYLES = `
/* ══════════════════════════════════════════
   SCREEN: #pdoc always in DOM, always hidden
   (shown only via direct inline style in doPrint)
══════════════════════════════════════════ */
#pdoc {
  display: none !important;
  font-family: 'Arial', sans-serif;
  font-size: 8.5pt;
  color: #1a1a2e;
  background: white;
  line-height: 1.35;
  -webkit-print-color-adjust: exact;
  print-color-adjust: exact;
}

/* A4 page boxes */
.ppage {
  width: 210mm;
  min-height: 297mm;
  margin: 0 auto 8mm;
  padding: 11mm 13mm 14mm;
  background: white;
  position: relative;
  page-break-after: always;
  break-after: page;
}
.ppage:last-child { page-break-after: auto; break-after: auto; margin-bottom: 0; }

/* ══════════════════════════════════════════
   @MEDIA PRINT — Electron Chromium reliable:
   Use visibility (not display:none) on body.
   #pdoc subtree gets visibility:visible.
══════════════════════════════════════════ */
@media print {
  @page { size: A4 portrait; margin: 0; }

  html, body {
    visibility: hidden !important;
    background: white !important;
    margin: 0 !important;
    padding: 0 !important;
  }

  #pdoc {
    visibility: visible !important;
    display: block !important;
    position: absolute !important;
    top: 0 !important; left: 0 !important;
    width: 100% !important;
    height: auto !important;
    overflow: visible !important;
    z-index: auto !important;
    background: white !important;
    -webkit-print-color-adjust: exact !important;
    print-color-adjust: exact !important;
  }

  #pdoc * { visibility: visible !important; }

  .ppage {
    width: 100% !important;
    min-height: auto !important;
    padding: 11mm 13mm 14mm !important;
    margin: 0 !important;
    page-break-after: always !important;
    break-after: page !important;
    box-shadow: none !important;
  }
  .ppage:last-child { page-break-after: auto !important; break-after: auto !important; }
  .pfooter { position: fixed !important; bottom: 5mm !important; left: 13mm !important; right: 13mm !important; }
}

/* ══════════════════════════════════════════
   COMMON LAYOUT CLASSES
══════════════════════════════════════════ */
.pstripe { height:4mm; background:#0f172a; margin-bottom:6mm; }
.ph { display:flex; justify-content:space-between; align-items:flex-start;
  border-bottom:.5mm solid #0f172a; padding-bottom:3mm; margin-bottom:3mm; }
.ph-ref  { font-size:6.5pt; color:#64748b; }
.ph-tit  { font-size:11pt; font-weight:700; text-transform:uppercase; letter-spacing:.03em; }
.ph-sub  { font-size:7.5pt; color:#475569; margin-top:.5mm; }
.ph-r    { text-align:right; }
.pg-note { font-size:6.5pt; color:#94a3b8; margin-top:1.5mm; }
.badge   { display:inline-block; font-size:7.5pt; font-weight:700; padding:1.5mm 3.5mm;
  border-radius:2mm; letter-spacing:.05em; }
.badge-b { background:#eff6ff; color:#1d4ed8; border:.3mm solid #bfdbfe; }
.badge-g { background:#f0fdf4; color:#15803d; border:.3mm solid #bbf7d0; }
.badge-o { background:#fff7ed; color:#c2410c; border:.3mm solid #fed7aa; }
.badge-p { background:#faf5ff; color:#7e22ce; border:.3mm solid #e9d5ff; }
.badge-r { background:#fff1f2; color:#be123c; border:.3mm solid #fecdd3; }
.badge-a { background:#fffbeb; color:#b45309; border:.3mm solid #fde68a; }
.badge-s { background:#f0f9ff; color:#0369a1; border:.3mm solid #bae6fd; }
.lbar   { display:flex; border:.3mm solid #e2e8f0; border-radius:1.5mm; overflow:hidden; margin-bottom:3mm; }
.lbar-c { flex:1; padding:1.5mm 2.5mm; border-right:.3mm solid #e2e8f0; background:#f8fafc; }
.lbar-c:last-child { border-right:none; }
.lbar-lbl { font-size:6.5pt; color:#94a3b8; }
.lbar-val { font-size:7.5pt; font-weight:700; color:#0f172a; font-family:monospace; }
.p2 { display:grid; grid-template-columns:1fr 1fr; gap:3.5mm; margin-bottom:3.5mm; }
.p3 { display:grid; grid-template-columns:1fr 1fr 1fr; gap:3mm; margin-bottom:3mm; }
.pfc { grid-column:1/-1; }
.psec { margin-bottom:3mm; border:.3mm solid #e2e8f0; border-radius:1.5mm; overflow:hidden; break-inside:avoid; }
.pst  { background:#1e293b; color:white; font-size:7pt; font-weight:700;
  text-transform:uppercase; letter-spacing:.06em; padding:1.5mm 2.5mm; }
.pst.b{background:#1e3a5f} .pst.g{background:#14532d} .pst.o{background:#7c2d12}
.pst.p{background:#3b0764} .pst.r{background:#881337} .pst.s{background:#0c4a6e}
.ptb  { width:100%; border-collapse:collapse; font-size:7.5pt; }
.ptb tr { border-bottom:.2mm solid #f1f5f9; }
.ptb tr:last-child { border-bottom:none; }
.ptb tr.hi { background:#fffbeb; }
.ptb td   { padding:1.3mm 2.5mm; vertical-align:middle; }
.ptb td.L { color:#475569; width:56%; }
.ptb td.V { text-align:right; font-weight:600; color:#0f172a; font-family:monospace; }
.ptb tr.hi td { color:#92400e!important; font-weight:700!important; }
.pztb { width:100%; border-collapse:collapse; font-size:7pt; margin-bottom:3mm;
  border:.3mm solid #e2e8f0; border-radius:1.5mm; overflow:hidden; }
.pztb thead tr { background:#1e293b; color:white; }
.pztb thead th { padding:1.5mm 2mm; font-weight:700; font-size:6.5pt; text-transform:uppercase; }
.pztb thead th:first-child { text-align:left; }
.pztb thead th:not(:first-child) { text-align:center; }
.pztb tbody tr { border-bottom:.2mm solid #f1f5f9; }
.pztb tbody td { padding:1.3mm 2mm; }
.pztb tbody td:first-child { color:#475569; }
.pztb tbody td:not(:first-child) { text-align:center; font-family:monospace; font-weight:600; }
.pztb tbody tr.hi td { color:#92400e!important; font-weight:700!important; }
.pbigs { display:flex; gap:2.5mm; margin-bottom:3mm; }
.pbig  { flex:1; border:.3mm solid #e2e8f0; border-radius:1.5mm; padding:2mm 2.5mm; background:#f8fafc; text-align:center; }
.pbig-l { font-size:6.5pt; color:#64748b; }
.pbig-v { font-size:10pt; font-weight:700; font-family:monospace; color:#0f172a; margin-top:.5mm; }
.pbig-s { font-size:6pt; color:#94a3b8; margin-top:.5mm; }
.pbig.a { border-color:#fde68a; background:#fffbeb; } .pbig.a .pbig-v{color:#92400e}
.pbig.g { border-color:#bbf7d0; background:#f0fdf4; } .pbig.g .pbig-v{color:#15803d}
.pbig.b { border-color:#bfdbfe; background:#eff6ff; } .pbig.b .pbig-v{color:#1d4ed8}
.pfooter { position:absolute; bottom:6mm; left:13mm; right:13mm;
  display:flex; justify-content:space-between; font-size:6.5pt; color:#94a3b8;
  border-top:.2mm solid #e2e8f0; padding-top:1.5mm; }
.psign  { width:100%; border-collapse:collapse; font-size:7pt; border:.3mm solid #e2e8f0; margin-top:3.5mm; }
.psign th { background:#f1f5f9; padding:1.5mm 2.5mm; font-weight:700; text-align:center;
  border:.3mm solid #e2e8f0; color:#475569; font-size:6.5pt; text-transform:uppercase; }
.psign td { padding:4mm 2.5mm 2mm; border:.3mm solid #e2e8f0; vertical-align:top; }
.psign .sl { font-size:6.5pt; color:#94a3b8; }
.psign .sv { font-weight:600; color:#0f172a; margin-top:.5mm; }
.psign .sline { height:8mm; border-bottom:.3mm solid #cbd5e1; margin-top:2mm; }
.ctbox   { border:.5mm double #0f172a; padding:4mm 6mm; text-align:center; margin:5mm 0; }
.ctbox h1{ font-size:12pt; font-weight:700; letter-spacing:.04em; margin:0 0 1.5mm; text-transform:uppercase; }
.ctbox p { font-size:8.5pt; color:#475569; margin:0; }
.cmeta   { display:grid; grid-template-columns:1fr 1fr; border:.3mm solid #cbd5e1; margin:4mm 0; }
.cmc     { padding:2mm 3.5mm; border-right:.3mm solid #cbd5e1; border-bottom:.3mm solid #cbd5e1; }
.cmc:nth-child(2n){ border-right:none; }
.cmc:nth-last-child(-n+2){ border-bottom:none; }
.cml { font-size:6.5pt; color:#94a3b8; text-transform:uppercase; letter-spacing:.05em; }
.cmv { font-size:8.5pt; font-weight:700; color:#1a1a2e; font-family:monospace; margin-top:.5mm; }
.toc h3 { font-size:7.5pt; text-transform:uppercase; letter-spacing:.07em; color:#475569;
  border-bottom:.3mm solid #e2e8f0; padding-bottom:1.5mm; margin-bottom:2.5mm; }
.tocr  { display:flex; justify-content:space-between; align-items:center;
  padding:1.5mm 2.5mm; border-bottom:.2mm solid #f1f5f9; font-size:8pt; }
.tocc  { font-weight:700; color:#0f172a; width:16mm; font-family:monospace; }
.tocn  { flex:1; color:#334155; }
.tocd  { flex:1; border-bottom:.2mm dotted #cbd5e1; margin:0 1.5mm 1.5mm; height:0; align-self:flex-end; }
.tocp  { color:#94a3b8; font-size:7pt; font-family:monospace; }
.clogor{ display:flex; justify-content:space-between; align-items:flex-start;
  margin-bottom:4mm; padding-bottom:3mm; border-bottom:.3mm solid #e2e8f0; }
.clgt  { font-size:7pt; color:#64748b; line-height:1.5; }
.clgt strong { color:#1a1a2e; }
`;

/* ══════════════════════════════════════════════
   DARK UI COMPONENTS
══════════════════════════════════════════════ */
const mono = { fontFamily:"'Courier New',monospace" };

const IF = ({ label, value, onChange, unit, readOnly, hint, type="text" }) => (
  <div style={{display:"flex",alignItems:"flex-start",gap:8,marginBottom:10}}>
    <label style={{fontSize:11,color:"#94a3b8",width:168,flexShrink:0,paddingTop:7,lineHeight:"1.3"}}>{label}</label>
    <div style={{display:"flex",alignItems:"center",gap:8,flex:1,minWidth:0}}>
      <input type={type} value={value} readOnly={readOnly}
        onChange={onChange?(e)=>onChange(e.target.value):undefined}
        style={{padding:"5px 10px",borderRadius:6,fontSize:12,...mono,
          background:readOnly?"#1e293b":"#0f172a",
          border:readOnly?"1px solid rgba(251,191,36,.4)":"1px solid #334155",
          color:readOnly?"#fbbf24":"#f1f5f9",width:"100%",maxWidth:220,outline:"none"}}/>
      {unit&&<span style={{fontSize:11,color:"#475569",width:40,flexShrink:0}}>{unit}</span>}
    </div>
    {hint&&<span style={{fontSize:10,color:"#334155",paddingTop:7,fontStyle:"italic"}}>{hint}</span>}
  </div>
);

const STi = ({children}) => (
  <div style={{display:"flex",alignItems:"center",gap:8,margin:"16px 0 10px",paddingTop:4}}>
    <div style={{width:3,height:14,background:"#fbbf24",borderRadius:99}}/>
    <span style={{fontSize:10,fontWeight:700,color:"#fbbf24",textTransform:"uppercase",letterSpacing:"0.1em"}}>{children}</span>
  </div>
);

const Card = ({children,style={}}) => (
  <div style={{background:"#0f172a",border:"1px solid #1e293b",borderRadius:12,padding:20,...style}}>
    {children}
  </div>
);

const DRow = ({label,value,hi,bold}) => (
  <tr style={{borderBottom:"1px solid #0f172a",background:hi?"rgba(251,191,36,.06)":"transparent"}}>
    <td style={{padding:"5px 10px",fontSize:11,color:bold?"#e2e8f0":"#64748b",fontWeight:bold?600:400}}>{label}</td>
    <td style={{padding:"5px 10px",textAlign:"right",fontSize:11,...mono,
      color:hi?"#fbbf24":bold?"#f1f5f9":"#94a3b8",fontWeight:hi||bold?700:400}}>{fd(value)}</td>
  </tr>
);

const DTable = ({title,color,children}) => {
  const bg={blue:"rgba(37,99,235,.15)",green:"rgba(21,128,61,.15)",orange:"rgba(194,65,12,.15)",
    purple:"rgba(126,34,206,.15)",red:"rgba(190,18,60,.15)",slate:"rgba(100,116,139,.15)",sky:"rgba(14,165,233,.15)"};
  return (
    <div style={{marginBottom:14,border:"1px solid #1e293b",borderRadius:8,overflow:"hidden"}}>
      {title&&<div style={{padding:"6px 10px",background:bg[color]||bg.slate}}>
        <span style={{fontSize:10,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.08em",color:"#e2e8f0"}}>{title}</span>
      </div>}
      <table style={{width:"100%"}}><tbody>{children}</tbody></table>
    </div>
  );
};

const Stat = ({label,value,unit,sub,color="amber"}) => {
  const c={amber:"#fbbf24",cyan:"#22d3ee",green:"#4ade80",slate:"#94a3b8",sky:"#38bdf8"};
  return (
    <div style={{background:"#1e293b",borderRadius:8,padding:12,border:"1px solid #334155"}}>
      <div style={{fontSize:10,color:"#64748b",marginBottom:3}}>{label}</div>
      <div style={{fontSize:18,fontWeight:700,...mono,color:c[color]}}>{value}
        {unit&&<span style={{fontSize:11,marginLeft:4,color:"#475569"}}>{unit}</span>}
      </div>
      {sub&&<div style={{fontSize:10,color:"#334155",marginTop:2}}>{sub}</div>}
    </div>
  );
};

const RHdr = ({code,name,color,poste,tension,dep1,date}) => {
  const g={blue:"linear-gradient(to right,#172554,#1e3a8a)",
    green:"linear-gradient(to right,#052e16,#14532d)",
    orange:"linear-gradient(to right,#431407,#7c2d12)",
    purple:"linear-gradient(to right,#2e1065,#3b0764)",
    red:"linear-gradient(to right,#4c0519,#881337)",
    sky:"linear-gradient(to right,#0c1a3a,#0c4a6e)"};
  const t={blue:"#93c5fd",green:"#86efac",orange:"#fdba74",purple:"#d8b4fe",red:"#fda4af",sky:"#7dd3fc"};
  return (
    <div style={{background:g[color],borderRadius:12,padding:16,marginBottom:16,border:`1px solid ${t[color]}33`}}>
      <div style={{fontSize:10,fontWeight:700,color:t[color],textTransform:"uppercase",letterSpacing:"0.1em",marginBottom:4}}>
        Fiche de Réglage Provisoire · DOS.FR01.DPS02
      </div>
      <div style={{fontSize:15,fontWeight:700,color:"white"}}>PROTECTION {code} — {name}</div>
      <div style={{fontSize:11,color:t[color],marginTop:4}}>
        Poste : <strong style={{color:"white"}}>{poste}</strong> &nbsp;|&nbsp;
        Départ {tension} KV N°: {dep1} &nbsp;|&nbsp; {date}
      </div>
    </div>
  );
};

const ZT = ({rows,zones,color="amber"}) => {
  const c={amber:"#fbbf24",green:"#4ade80",red:"#f87171",blue:"#60a5fa",sky:"#38bdf8"};
  return (
    <div style={{border:"1px solid #1e293b",borderRadius:8,overflow:"hidden",marginBottom:14}}>
      <div style={{overflowX:"auto"}}>
        <table style={{width:"100%",minWidth:480}}>
          <thead>
            <tr style={{background:"#1e293b"}}>
              <th style={{padding:"7px 10px",textAlign:"left",fontSize:10,color:"#64748b",fontWeight:600}}>Paramètre</th>
              {zones.map(z=><th key={z} style={{padding:"7px 10px",textAlign:"center",fontSize:10,fontWeight:700,color:c[color]}}>{z}</th>)}
            </tr>
          </thead>
          <tbody>
            {rows.map((row,i)=>(
              <tr key={i} style={{borderBottom:"1px solid #0f172a",background:row.hi?"rgba(251,191,36,.05)":"transparent"}}>
                <td style={{padding:"5px 10px",fontSize:11,color:row.bold?"#e2e8f0":"#64748b",fontWeight:row.bold?600:400}}>{row.lbl}</td>
                {row.vals.map((v,j)=>(
                  <td key={j} style={{padding:"5px 10px",textAlign:"center",fontSize:row.hi?13:11,...mono,
                    fontWeight:row.hi||row.bold?700:400,color:row.hi?c[color]:row.bold?"#f1f5f9":"#94a3b8"}}>{fd(v)}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

/* ══════════════════════════════════════════════
   PRINT COMPONENTS
══════════════════════════════════════════════ */
const PS  = ({title,color,children}) => (<div className="psec">{title&&<div className={`pst${color?" "+color:""}`}>{title}</div>}{children}</div>);
const PR  = ({label,value,hi,bold}) => (<tr className={hi?"hi":""}><td className="L" style={bold?{fontWeight:700,color:"#1e293b"}:{}}>{label}</td><td className="V" style={hi?{fontWeight:700}:{}}>{fd(value)}</td></tr>);
const PZT = ({zones,rows}) => (
  <table className="pztb">
    <thead><tr><th style={{textAlign:"left",width:"34%"}}>Paramètre</th>{zones.map(z=><th key={z}>{z}</th>)}</tr></thead>
    <tbody>{rows.map((row,i)=><tr key={i} className={row.hi?"hi":""}><td style={row.bold?{color:"#0f172a",fontWeight:700}:{}}>{row.lbl}</td>{row.vals.map((v,j)=><td key={j}>{fd(v)}</td>)}</tr>)}</tbody>
  </table>
);
const PFoot = ({poste,tension,dep1,ref_,indice,pg,tot}) => (
  <div className="pfooter">
    <span>{ref_} · Indice {indice} · {poste} · {tension} kV N°: {dep1}</span>
    <span>Page {pg}/{tot}</span>
  </div>
);
const PSign = ({by,date}) => (
  <table className="psign">
    <thead><tr>{["DOS/SSE · Élaboré par","DOS/SSE · Vérifié par","DOS/SSE · Validé par","DTC · Affiché par","DTC · Validé par"].map(c=><th key={c}>{c}</th>)}</tr></thead>
    <tbody><tr>
      <td><div className="sl">Nom :</div><div className="sv">{by}</div><div className="sl" style={{marginTop:4}}>Date : {date}</div><div className="sline"/><div className="sl">Signature :</div></td>
      {[1,2,3,4].map(i=><td key={i}><div className="sl">Nom :</div><div style={{height:6,borderBottom:".3mm solid #cbd5e1",marginTop:2}}/><div className="sl" style={{marginTop:4}}>Date :</div><div className="sline"/><div className="sl">Signature :</div></td>)}
    </tr></tbody>
  </table>
);
const LBar = ({items}) => (
  <div className="lbar">{items.map((x,i)=><div key={i} className="lbar-c"><div className="lbar-lbl">{x.l}</div><div className="lbar-val">{x.v}</div></div>)}</div>
);
const BigStats = ({items}) => (
  <div className="pbigs">{items.map((x,i)=><div key={i} className={`pbig${x.c?" "+x.c:""}`}><div className="pbig-l">{x.l}</div><div className="pbig-v">{x.v}{x.u&&<span style={{fontSize:"7pt",fontWeight:400,marginLeft:2}}>{x.u}</span>}</div>{x.s&&<div className="pbig-s">{x.s}</div>}</div>)}</div>
);

/* ══════════════════════════════════════════════
   PRINT DOCUMENT
══════════════════════════════════════════════ */
function PrintDoc({G,C,zp,red,p142}) {
  const T=10;
  const foot=pg=><PFoot poste={G.poste} tension={G.tension} dep1={G.depart1} ref_={G.refDoc} indice={G.indice} pg={pg} tot={T}/>;
  const lb=<LBar items={[{l:"Poste",v:G.poste},{l:"Tension",v:`${G.tension} kV`},{l:"Longueur",v:`${C.Lt} km`},{l:"Z prim.",v:`${C.Zt} Ω`},{l:"Zd (sec.)",v:`${C.Zd} Ω`},{l:"∠",v:`${C.ang}°`}]}/>;

  const zoneRows = (C,zp) => [
    {lbl:"Portée (Ω sec.)",vals:[C.z1,C.z2,C.z3,C.z4,C.zP],bold:true,hi:true},
    {lbl:"% de Zd",vals:[zp.z1_pct+"%",zp.z2_pct+"%",zp.z3_pct+"%",zp.z4_pct+"%",zp.zp_pct+"%"]},
    {lbl:"Comp. kZ",vals:[C.kz,C.kz,C.kz,C.kz,C.kz]},
    {lbl:"R1G / R1Ph (Ω)",vals:[`${C.r1g}/${C.r1ph}`,`${C.r1g}/${C.r1ph}`,`${C.r1g}/${C.r1ph}`,`${C.r1g}/${C.r1ph}`,`${C.r1g}/${C.r1ph}`]},
    {lbl:"Temporisation",vals:[zp.tZ1+" ms",zp.tZ2+" ms",R(pf(zp.tZ3)/1000,1)+" s",R(pf(zp.tZ4)/1000,1)+" s",R(pf(zp.tZp)/1000,1)+" s"],bold:true},
    {lbl:"Direction",vals:["Avant","Avant","Avant","Arrière","Aval"]},
  ];

  // REL670 primary zones
  const rel670zones = (C) => {
    const Xp = C.Xt; // primary X
    const ang_r = C.ang * Math.PI/180;
    const pcts = { z1:pf(C.zp_rel670?.z1||"80"), z2:pf(C.zp_rel670?.z2||"120"),
                   zp:pf(C.zp_rel670?.zp||"130"), z3:pf(C.zp_rel670?.z3||"290"), z4:pf(C.zp_rel670?.z4||"58") };
    const zm = (pct) => {
      const Xv = R(Xp * pct/100, 2);
      const Rv = R(Xv / Math.tan(ang_r), 2);
      const X0v = R(Xv * (1 + 3*C.kz), 2);
      const R0v = R(Rv * (1 + 3*C.kz_r), 2);
      return {X1:Xv, R1:Rv, X0:X0v, R0:R0v};
    };
    return { z1:zm(pcts.z1), z2:zm(pcts.z2), zp:zm(pcts.zp), z3:zm(pcts.z3), z4:zm(pcts.z4) };
  };

  // 7SA82 secondary zones
  const sa82zones = (C) => {
    const pcts = { z1:pf(C.sa82?.z1||"70"), z2:pf(C.sa82?.z2||"108"),
                   z3:pf(C.sa82?.z3||"181"), z4:pf(C.sa82?.z4||"125") };
    return {
      z1: R(C.Zd * pcts.z1/100, 3), z2: R(C.Zd * pcts.z2/100, 3),
      z3: R(C.Zd * pcts.z3/100, 3), z4: R(C.Zd * pcts.z4/100, 3),
    };
  };

  return (
    <>
      <style>{PRINT_STYLES}</style>
      <div id="pdoc">

      {/* PAGE 1 — COVER */}
      <div className="ppage">
        <div className="pstripe"/>
        <div className="clogor">
          <div className="clgt">
            <div><strong>⚡ المكتب الوطني للكهرباء والماء الصالح للشرب</strong></div>
            <div>Office National de l'Électricité et de l'Eau Potable</div>
            <div><strong>Pôle Industriel · DCT · Direction Opérateur Système</strong></div>
          </div>
          <div className="clgt" style={{textAlign:"right"}}>
            <div><strong>Réf :</strong> {G.refDoc}</div>
            <div><strong>Indice :</strong> {G.indice}</div>
            <div><strong>Date :</strong> {G.date}</div>
          </div>
        </div>
        <div className="ctbox">
          <h1>Demande de Calcul de Réglage des Protections</h1>
          <p>« Départ ou Transfert »</p>
        </div>
        <div className="cmeta">
          {[["Poste",G.poste],["Tension",`${G.tension} kV`],["Départ",G.depart1],
            ["Élaboré par",G.elaborePar],["Date",G.date],["Référence",G.refDoc],
            ["Z prim.",`${C.Zt} Ω  ∠${C.ang}°`],["Zd (sec.)",`${C.Zd} Ω`],
          ].map(([l,v])=><div key={l} className="cmc"><div className="cml">{l}</div><div className="cmv">{v}</div></div>)}
        </div>
        <div style={{border:".3mm solid #e2e8f0",borderRadius:"1.5mm",overflow:"hidden",marginBottom:"4mm"}}>
          <div style={{background:"#1e293b",color:"white",padding:"1.5mm 3mm",fontSize:"7pt",fontWeight:700,textTransform:"uppercase"}}>
            Protections Installées sur le Départ
          </div>
          <table style={{width:"100%",borderCollapse:"collapse",fontSize:"7.5pt"}}>
            <thead><tr style={{background:"#f8fafc",color:"#475569"}}>
              {["Protection","Code ANSI","Relais","Code Cortec"].map(h=><th key={h} style={{padding:"1.5mm 2.5mm",textAlign:"left",borderBottom:".2mm solid #e2e8f0",fontWeight:600,fontSize:"7pt"}}>{h}</th>)}
            </tr></thead>
            <tbody>
              {[["Distance N°1","[21]-1","D60 · GE","GE"],["Distance N°2","[21]-2","P444 · Alstom","ALSTOM"],
                ["Dir. Terre","[32N]","P444","—"],["Diff. ligne","[87L]","—","—"],
                ["Max. U","[59]","D60","—"],["Max. U Hom.","[59N]","P142","ALSTOM"],
                ["Min. U","[27]","—","—"],["Réenclencheur","[79]","P142","ALSTOM"],
                ["Contrôle synchro","[25]","D25/P442","—"],["50BF","[50BF]","DBF+P142","—"],
                ["7SA82 (Siemens)","[21]","7SA82","SIEMENS"],["REL 670 (ABB)","[21]","REL 670","ABB"],
              ].map(([n,c,t,co],i)=>(
                <tr key={i} style={{borderBottom:".2mm solid #f1f5f9",background:i%2===0?"white":"#fafafa"}}>
                  <td style={{padding:"1.3mm 2.5mm",color:"#334155"}}>{n}</td>
                  <td style={{padding:"1.3mm 2.5mm",fontFamily:"monospace",fontWeight:700}}>{c}</td>
                  <td style={{padding:"1.3mm 2.5mm",fontWeight:600,color:"#1e40af"}}>{t}</td>
                  <td style={{padding:"1.3mm 2.5mm",color:"#64748b"}}>{co}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="toc">
          <h3>Table des Matières</h3>
          {[["p.1","Page de Garde"],["p.2","Calculs Impédances"],["p.3","P444 · Alstom/GE"],
            ["p.4","D60 · GE Multilin"],["p.5","DBF · Matériel"],["p.6","D25 · Synchrochek"],
            ["p.7","P142 · Alstom"],["p.8","7SA82 · Siemens"],["p.9","REL 670 · ABB"],["p.10","Annexe"],
          ].map(([pg,nm])=>(
            <div key={pg} className="tocr"><span className="tocc">{pg}</span><span className="tocn">{nm}</span><span className="tocd"/><span className="tocp">{pg}</span></div>
          ))}
        </div>
        <PSign by={G.elaborePar} date={G.date}/>{foot(1)}
      </div>

      {/* PAGE 2 — CALCULS */}
      <div className="ppage">
        <div className="ph">
          <div><div className="ph-ref">{G.refDoc} · Indice {G.indice}</div><div className="ph-tit">Résumé des Calculs d'Impédances</div><div className="ph-sub">{G.poste} · Départ {G.tension} KV N°: {G.depart1}</div></div>
          <div className="ph-r"><span className="badge badge-a">CALCULS</span><div className="pg-note">Page 2/{T}</div></div>
        </div>
        {lb}
        <BigStats items={[
          {l:"Longueur",v:C.Lt,u:"km",s:`${C.segC.length} segment(s)`,c:"b"},
          {l:"R Total",v:C.Rt,u:"Ω"},{l:"X Total",v:C.Xt,u:"Ω"},
          {l:"Z Primaire",v:C.Zt,u:"Ω",s:`∠${C.ang}°`,c:"a"},
          {l:"Zd (secondaire)",v:C.Zd,u:"Ω",s:`×${C.cv}`,c:"g"},
        ]}/>
        <PS title="Segments de Ligne">
          <table style={{width:"100%",borderCollapse:"collapse",fontSize:"7pt"}}>
            <thead><tr style={{background:"#f1f5f9",color:"#475569"}}>
              {["Segment","Câble","L km","R Ω/km","X Ω/km","Z Ω/km","R Ω","X Ω","Z Ω"].map(h=>(
                <th key={h} style={{padding:"1.5mm 2mm",fontWeight:600,textAlign:["Segment","Câble"].includes(h)?"left":"right",borderBottom:".2mm solid #e2e8f0"}}>{h}</th>
              ))}
            </tr></thead>
            <tbody>
              {C.segC.map((s,i)=>(
                <tr key={i} style={{borderBottom:".2mm solid #f1f5f9",background:i%2===0?"white":"#fafafa"}}>
                  <td style={{padding:"1.3mm 2mm",color:"#334155"}}>{s.name}</td>
                  <td style={{padding:"1.3mm 2mm"}}>{s.cable}</td>
                  <td style={{padding:"1.3mm 2mm",textAlign:"right",fontFamily:"monospace",fontWeight:700}}>{s.length}</td>
                  <td style={{padding:"1.3mm 2mm",textAlign:"right",fontFamily:"monospace"}}>{s.r_km}</td>
                  <td style={{padding:"1.3mm 2mm",textAlign:"right",fontFamily:"monospace"}}>{s.x_km}</td>
                  <td style={{padding:"1.3mm 2mm",textAlign:"right",fontFamily:"monospace"}}>{s.z_km}</td>
                  <td style={{padding:"1.3mm 2mm",textAlign:"right",fontFamily:"monospace",fontWeight:700,color:"#1e40af"}}>{s.R}</td>
                  <td style={{padding:"1.3mm 2mm",textAlign:"right",fontFamily:"monospace",fontWeight:700,color:"#1e40af"}}>{s.X}</td>
                  <td style={{padding:"1.3mm 2mm",textAlign:"right",fontFamily:"monospace",fontWeight:700,color:"#92400e"}}>{s.Z}</td>
                </tr>
              ))}
              <tr style={{background:"#fffbeb",borderTop:".4mm solid #fde68a"}}>
                <td colSpan={2} style={{padding:"2mm",fontWeight:700,color:"#92400e"}}>TOTAL = {C.Lt} km</td>
                <td/><td/><td/><td style={{padding:"1.5mm 2mm",textAlign:"right",fontFamily:"monospace",color:"#64748b"}}>—</td>
                <td style={{padding:"1.5mm 2mm",textAlign:"right",fontFamily:"monospace",fontWeight:700,color:"#92400e"}}>{C.Rt}</td>
                <td style={{padding:"1.5mm 2mm",textAlign:"right",fontFamily:"monospace",fontWeight:700,color:"#92400e"}}>{C.Xt}</td>
                <td style={{padding:"1.5mm 2mm",textAlign:"right",fontFamily:"monospace",fontWeight:700,color:"#92400e"}}>{C.Zt}</td>
              </tr>
            </tbody>
          </table>
        </PS>
        <div className="p2">
          <PS title="Réducteurs"><table className="ptb"><tbody>
            <PR label="Rapport TT" value={`${red.vt_prim}/√3 ÷ ${red.vt_sec}/√3 V`} bold/>
            <PR label="Rapport TT num." value={`${C.vtr}:1`}/>
            <PR label="Rapport TC" value={`${red.ct_prim} / ${red.ct_sec} A`} bold/>
            <PR label="Facteur conversion" value={C.cv} hi/>
          </tbody></table></PS>
          <PS title="Impédances Secondaires"><table className="ptb"><tbody>
            <PR label="Zd (vue sec.)" value={`${C.Zd} Ω`} hi/>
            <PR label="Rd" value={`${C.Rd} Ω`} bold/><PR label="Xd" value={`${C.Xd} Ω`} bold/>
            <PR label="Angle" value={`${C.ang}°`} bold/>
            <PR label="Z0d (homopolaire)" value={`${C.Z0d} Ω`}/><PR label="kZ" value={C.kz}/>
          </tbody></table></PS>
        </div>
        <PS title="Zones — Tableau Récapitulatif">
          <PZT zones={["Z1","Z2","Z3","Z4 Arr.","Zp Pilote"]} rows={zoneRows(C,zp)}/>
        </PS>
        <PSign by={G.elaborePar} date={G.date}/>{foot(2)}
      </div>

      {/* PAGE 3 — P444 */}
      <div className="ppage">
        <div className="ph"><div><div className="ph-ref">{G.refDoc}</div><div className="ph-tit">PROTECTION P444 — Alstom/GE</div><div className="ph-sub">{G.poste} · {G.tension} KV N°: {G.depart1}</div></div><div className="ph-r"><span className="badge badge-b">P444</span><div className="pg-note">Page 3/{T}</div></div></div>
        {lb}
        <div className="p2">
          <PS title="Ligne + Réducteurs" color="b"><table className="ptb"><tbody>
            <PR label="Z total prim." value={`${C.Zt} Ω ∠${C.ang}°`} bold/><PR label="Zd vue sec." value={`${C.Zd} Ω`} hi/>
            <PR label="TT" value={`${red.vt_prim}/√3 / ${red.vt_sec}/√3 V`} bold/><PR label="TC" value={`${red.ct_prim}/${red.ct_sec} A`} bold/>
          </tbody></table></PS>
          <PS title="Configuration" color="b"><table className="ptb"><tbody>
            <PR label="Mode standard" value="P.R.A.Z2" bold/><PR label="Mode déclt." value="Mono Z1Z2+TA" bold/>
            <PR label="Pompage ΔR=ΔX" value={`${C.blinder} Ω`} bold/><PR label="Réenclencheur" value="1 cycle mono" bold/>
          </tbody></table></PS>
        </div>
        <PS title="Zones P444" color="b"><PZT zones={["Z1","Z2","Z3","Z4","Zp"]} rows={zoneRows(C,zp)}/></PS>
        <div className="p3">
          <PS title="Logique Distance" color="b"><table className="ptb"><tbody>
            <PR label="Mode standard" value="P.R.A.Z2" bold/><PR label="Réencl. Z1" value="1" bold/>
            <PR label="Réencl. Z2" value="1" bold/><PR label="Réencl. TAC" value="1" bold/>
          </tbody></table></PS>
          <PS title="Réenclencheur" color="b"><table className="ptb"><tbody>
            <PR label="Mode mono" value="1" bold/><PR label="Tempo cy.1" value="1,5 s" bold/>
            <PR label="Blocage" value="60 s" bold/><PR label="Fermeture" value="0,1 s" bold/>
          </tbody></table></PS>
          <PS title="Pompage + Ctrl" color="b"><table className="ptb"><tbody>
            <PR label="ΔR = ΔX" value={`${C.blinder} Ω`} hi/><PR label="IN> (%max)" value="20 %" />
            <PR label="V vive >" value="46 V" bold/><PR label="V morte <" value="12 V"/>
          </tbody></table></PS>
        </div>
        <PSign by={G.elaborePar} date={G.date}/>{foot(3)}
      </div>

      {/* PAGE 4 — D60 */}
      <div className="ppage">
        <div className="ph"><div><div className="ph-ref">{G.refDoc}</div><div className="ph-tit">PROTECTION D60 — GE Multilin</div><div className="ph-sub">{G.poste} · {G.tension} KV N°: {G.depart1}</div></div><div className="ph-r"><span className="badge badge-g">D60</span><div className="pg-note">Page 4/{T}</div></div></div>
        {lb}
        <div className="p2">
          <PS title="Système" color="g"><table className="ptb"><tbody>
            <PR label="TC prim./sec." value={`${red.ct_prim}/${red.ct_sec} A`} bold/><PR label="Rapport TT" value={`${C.vtr}:1`} bold/>
            <PR label="Zd" value={`${C.Zd} Ω`} hi/><PR label="Angle" value={`${C.ang}°`} bold/><PR label="Z0d" value={`${C.Z0d} Ω`} bold/>
          </tbody></table></PS>
          <PS title="Amorçage + Swing" color="g"><table className="ptb"><tbody>
            <PR label="Surintensité" value="1,500 pu" bold/><PR label="Sous-tension" value="0,200 pu"/>
            <PR label="Portée avant" value={`${C.porteeAv} Ω`} hi/><PR label="Portée arrière" value={`${C.porteeArr} Ω`} bold/>
          </tbody></table></PS>
        </div>
        <PS title="Zones D60 — Phase + Terre" color="g">
          <PZT zones={["Z1","Z2","Z3(Zp)","Z4","Z5"]} rows={[
            {lbl:"Portée Phase (Ω)",vals:[C.z1,C.z2,C.zP,C.z4,C.z3],bold:true,hi:true},
            {lbl:"Portée Terre (Ω)",vals:[C.z1,C.z2,C.zP,C.z4,C.z3],bold:true},
            {lbl:"Amp. Z0/Z1",vals:["3","3","3","3","3"]},
            {lbl:"Blinder (Ω)",vals:[C.blinder,C.blinder,C.blinder,C.blinder,C.blinder]},
            {lbl:"Tempo.",vals:["0 s","0,400 s","1,000 s","3,200 s","3,200 s"],bold:true},
            {lbl:"Direction",vals:["Avant","Avant","Avant","Arrière","Avant"]},
          ]}/>
        </PS>
        <PSign by={G.elaborePar} date={G.date}/>{foot(4)}
      </div>

      {/* PAGE 5 — DBF */}
      <div className="ppage">
        <div className="ph"><div><div className="ph-ref">{G.refDoc}</div><div className="ph-tit">PROTECTION DBF — Défaillance Disjoncteur</div><div className="ph-sub">{G.poste} · {G.tension} KV N°: {G.depart1}</div></div><div className="ph-r"><span className="badge badge-o">DBF</span><div className="pg-note">Page 5/{T}</div></div></div>
        {lb}
        <div className="p2">
          <PS title="Réglages Généraux" color="o"><table className="ptb"><tbody>
            <PR label="État" value="En service" bold/><PR label="TC" value={`${red.ct_prim}/${red.ct_sec} A`} bold/>
            <PR label="50BF 1P" value="Permis" bold/><PR label="50BF 3P" value="Permis" bold/>
          </tbody></table></PS>
          <PS title="Fonction 50BF (T1)" color="o"><table className="ptb"><tbody>
            <PR label="Démarrage H" value="0,2 A" hi/><PR label="Démarrage B" value="0,2 A" hi/>
            <PR label="t Mono T1" value="60 ms (deux bob.)" bold/><PR label="t 3P T2" value="60 ms (deux bob.)" bold/>
            <PR label="t 2e Éch." value="200 ms (encadrants)" bold/>
          </tbody></table></PS>
        </div>
        <PSign by={G.elaborePar} date={G.date}/>{foot(5)}
      </div>

      {/* PAGE 6 — D25 */}
      <div className="ppage">
        <div className="ph"><div><div className="ph-ref">{G.refDoc}</div><div className="ph-tit">SYNCHROCHEK D25</div><div className="ph-sub">{G.poste} · {G.tension} KV N°: {G.depart1}</div></div><div className="ph-r"><span className="badge badge-p">D25</span><div className="pg-note">Page 6/{T}</div></div></div>
        {lb}
        <div className="p2">
          <PS title="Ligne + Réducteurs" color="p"><table className="ptb"><tbody>
            <PR label="Total =" value={`${C.Lt} km`} bold/><PR label="Z / Zd" value={`${C.Zt} Ω / ${C.Zd} Ω`} bold/>
            <PR label="TT" value={`${red.vt_prim}V/√3 / ${red.vt_sec}V/√3`} bold/><PR label="TC" value={`${red.ct_prim}/${red.ct_sec} A`} bold/>
          </tbody></table></PS>
          <PS title="Contrôleur F25" color="p"><table className="ptb"><tbody>
            <PR label="CSS Ratio TT" value={`${C.vtr}:1`} hi/><PR label="CSS Déphasage" value="20 deg" bold/>
            <PR label="CSS Glis. fréq." value="100 mHz" bold/><PR label="CSS Tempo" value="0,5 s" bold/>
            <PR label="V vive B/L" value="46 V" bold/><PR label="V morte B/L" value="12 V" bold/>
          </tbody></table></PS>
        </div>
        <PSign by={G.elaborePar} date={G.date}/>{foot(6)}
      </div>

      {/* PAGE 7 — P142 */}
      <div className="ppage">
        <div className="ph"><div><div className="ph-ref">{G.refDoc}</div><div className="ph-tit">PROTECTION P142 — Alstom</div><div className="ph-sub">{G.poste} · {G.tension} KV N°: {G.depart1}</div></div><div className="ph-r"><span className="badge badge-r">P142</span><div className="pg-note">Page 7/{T}</div></div></div>
        {lb}
        <div className="p2">
          <PS title="50BF" color="r"><table className="ptb"><tbody>
            <PR label="I dém. phase" value={`${p142.bf_i_phase} A sec → ${C.bf_ih} A prim`} hi/>
            <PR label="t2 — CB défaillant" value={`${p142.bf_t2} ms`} hi/>
            <PR label="t1/t2/t3" value={`${p142.bf_t1}/${p142.bf_t2}/${p142.bf_t3} ms`} bold/>
            <PR label="Déclenchement" value="Triphasé — 2 bob." bold/>
          </tbody></table></PS>
          <PS title="50/51 + 67N" color="r"><table className="ptb"><tbody>
            <PR label="Seuil 50" value={`${p142.i_inst_pct}% In = ${C.i_inst} A prim`} hi/>
            <PR label="Seuil 51 / t51" value={`${p142.i_def_pct}% In = ${C.i_def} A — ${p142.t_def}s`} bold/>
            <PR label="I0 67N / t" value={`${p142.dir67n_i0} A — ${p142.dir67n_t} s`} hi/>
          </tbody></table></PS>
          <PS title="79 Réenclencheur" color="r"><table className="ptb"><tbody>
            <PR label="Mode" value={p142.r79_mode==="1"?"Monophasé":"Triphasé"} bold/>
            <PR label="t mort cy.1" value={`${p142.r79_t_dead1} s`} hi/>
            <PR label="t récupération" value={`${p142.r79_t_rec} s`} bold/>
          </tbody></table></PS>
          <PS title="59N + 74 TCS" color="r"><table className="ptb"><tbody>
            <PR label="U0 seuil / t" value={`${p142.u0_seuil} V — ${p142.u0_t} s`} hi/>
            <PR label="TCS seuil / t" value={`${p142.tcs_i} A — ${p142.tcs_t} s`} bold/>
          </tbody></table></PS>
        </div>
        <PSign by={G.elaborePar} date={G.date}/>{foot(7)}
      </div>

      {/* PAGE 8 — 7SA82 */}
      <div className="ppage">
        <div className="ph"><div><div className="ph-ref">{G.refDoc}</div><div className="ph-tit">PROTECTION 7SA82 — Siemens</div><div className="ph-sub">{G.poste} · {G.tension} KV N°: {G.depart1}</div></div><div className="ph-r"><span className="badge badge-s">7SA82 · SIEMENS</span><div className="pg-note">Page 8/{T}</div></div></div>
        {lb}
        <div className="p2">
          <PS title="Paramètres Ligne 7SA82" color="s"><table className="ptb"><tbody>
            <PR label="Longueur" value={`${C.Lt} km`} bold/>
            <PR label="Angle caract." value={`${C.ang}°`} bold/>
            <PR label="Kr (compensation R)" value={R((C.Rt0-C.Rt)/(3*C.Rt),3)} hi/>
            <PR label="Kx (compensation X)" value={R((C.Xt0-C.Xt)/(3*C.Xt),3)} hi/>
            <PR label="Seuil 3I0>" value="1,25 A (sec.)" bold/>
            <PR label="Seuil U0>" value="3 V (sec.)" bold/>
          </tbody></table></PS>
          <PS title="Réducteurs" color="s"><table className="ptb"><tbody>
            <PR label="TC" value={`${red.ct_prim}/${red.ct_sec} A`} bold/>
            <PR label="TT" value={`${red.vt_prim}/${red.vt_sec} V`} bold/>
            <PR label="Facteur conv." value={C.cv} bold/>
            <PR label="Zd" value={`${C.Zd} Ω (secondaire)`} hi/>
          </tbody></table></PS>
        </div>
        <PS title="Zones 7SA82 — Portée en X (secondaire) + Résistances R(P-T) / R(P-P)">
          <PZT zones={["Z1 (Fwd)","Z2 (Fwd)","Z3 (Fwd)","Z4 (Rev)","Z5 (Fwd)"]} rows={[
            {lbl:"Portée X (Ω sec.)",vals:[C.sa82_z1_x,C.sa82_z2_x,C.sa82_z3_x,C.sa82_z4_x,C.sa82_z5_x],bold:true,hi:true},
            {lbl:"R (P-T) Ω",vals:[C.sa82_z1_rpt,C.sa82_z2_rpt,C.sa82_z3_rpt,C.sa82_z4_rpt,C.sa82_z5_rpt]},
            {lbl:"R (P-P) Ω",vals:[C.sa82_z1_rpp,C.sa82_z2_rpp,C.sa82_z3_rpp,C.sa82_z4_rpp,C.sa82_z5_rpp]},
            {lbl:"Temporisation (1ph/3ph)",vals:[C.sa82_tz1,C.sa82_tz2,C.sa82_tz3,C.sa82_tz4,C.sa82_tz5],bold:true},
            {lbl:"Direction",vals:["Avant","Avant","Avant","Arrière","Avant"]},
          ]}/>
        </PS>
        <div className="p2">
          <PS title="Anti-pompage (OSM)" color="s"><table className="ptb"><tbody>
            <PR label="Mode" value="Activé" bold/><PR label="Tps blocage max." value="5 s" bold/>
            <PR label="Zones à bloquer" value="Z1 à Z5" bold/>
          </tbody></table></PS>
          <PS title="32N/Puissance homopolaire" color="s"><table className="ptb"><tbody>
            <PR label="Mode" value="Activé" bold/><PR label="Direction" value="En aval" bold/>
            <PR label="Puis. hom. min." value="3 VA" bold/><PR label="Tempo add." value="1 s" bold/>
          </tbody></table></PS>
        </div>
        <PSign by={G.elaborePar} date={G.date}/>{foot(8)}
      </div>

      {/* PAGE 9 — REL 670 */}
      <div className="ppage">
        <div className="ph"><div><div className="ph-ref">{G.refDoc}</div><div className="ph-tit">PROTECTION REL 670 — ABB</div><div className="ph-sub">{G.poste} · {G.tension} KV N°: {G.depart1}</div></div><div className="ph-r"><span className="badge badge-g">REL 670 · ABB</span><div className="pg-note">Page 9/{T}</div></div></div>
        {lb}
        <div className="p2">
          <PS title="Paramètres Ligne REL 670 (valeurs primaires HT)" color="g"><table className="ptb"><tbody>
            <PR label="IBase" value={`${red.ct_prim} A`} bold/>
            <PR label="UBase" value={`${red.vt_prim/1000} kV`} bold/>
            <PR label="X1 ligne (prim.)" value={`${C.Xt} Ω`} bold/>
            <PR label="R1 ligne (prim.)" value={`${C.Rt} Ω`} bold/>
            <PR label="X0 ligne (prim.)" value={`${C.Xt0} Ω`} bold/>
            <PR label="R0 ligne (prim.)" value={`${C.Rt0} Ω`} bold/>
            <PR label="Longueur" value={`${C.Lt} km`} bold/>
          </tbody></table></PS>
          <PS title="Réducteurs" color="g"><table className="ptb"><tbody>
            <PR label="CT prim./sec." value={`${red.ct_prim}/${red.ct_sec} A`} bold/>
            <PR label="VT prim./sec." value={`${red.vt_prim}/${red.vt_sec} V`} bold/>
            <PR label="Z1 ligne ∠" value={`${C.Zt} Ω ∠${C.ang}°`} hi/>
          </tbody></table></PS>
        </div>
        <PS title="Zones REL 670 — ZM01 à ZM05 (valeurs primaires HT en Ω)">
          <PZT zones={["ZM01 (Z1)","ZM02 (Z2)","ZM03 (Zp)","ZM04 (Z3)","ZM05 (Z4↩)"]} rows={[
            {lbl:"X1 (Ω prim.)",vals:[C.rel670_z1_x,C.rel670_z2_x,C.rel670_zp_x,C.rel670_z3_x,C.rel670_z4_x],bold:true,hi:true},
            {lbl:"R1 (Ω prim.)",vals:[C.rel670_z1_r,C.rel670_z2_r,C.rel670_zp_r,C.rel670_z3_r,C.rel670_z4_r],bold:true},
            {lbl:"X0 (Ω prim.)",vals:[C.rel670_z1_x0,C.rel670_z2_x0,C.rel670_zp_x0,C.rel670_z3_x0,C.rel670_z4_x0]},
            {lbl:"R0 (Ω prim.)",vals:[C.rel670_z1_r0,C.rel670_z2_r0,C.rel670_zp_r0,C.rel670_z3_r0,C.rel670_z4_r0]},
            {lbl:"RFPP (Ω/l)",vals:[C.rel670_rfpp1,C.rel670_rfpp2,C.rel670_rfpp3,C.rel670_rfpp3,C.rel670_rfpp3]},
            {lbl:"RFPE (Ω/l)",vals:[C.rel670_rfpe1,C.rel670_rfpe2,C.rel670_rfpe3,C.rel670_rfpe3,C.rel670_rfpe3]},
            {lbl:"tPP / tPE",vals:[zp.tZ1+" ms",zp.tZ2+" ms",R(pf(zp.tZp)/1000,1)+" s",R(pf(zp.tZ3)/1000,1)+" s",R(pf(zp.tZ4)/1000,1)+" s"],bold:true},
            {lbl:"Direction",vals:["Avant","Avant","Avant","Avant","Arrière"]},
          ]}/>
        </PS>
        <div className="p2">
          <PS title="Power Swing (RPSD)" color="g"><table className="ptb"><tbody>
            <PR label="X1InFw" value={`${C.rel670_psd_x} Ω`} bold/><PR label="R1Lin" value={`${C.rel670_psd_r} Ω`} bold/>
            <PR label="R1FInFw/Rv" value={`${C.rel670_psd_rf} Ω/l`} bold/><PR label="tP1/tP2" value="0,045 / 0,015 s" bold/>
          </tbody></table></PS>
          <PS title="SOTF + Fault Locator" color="g"><table className="ptb"><tbody>
            <PR label="Mode SOTF" value="ON — Niveau UI" bold/><PR label="tSOTF" value="0 s" bold/>
            <PR label="IMinOpPP" value="10 % IB" bold/><PR label="IMinOpPE" value="5 % IB" bold/>
          </tbody></table></PS>
        </div>
        <PSign by={G.elaborePar} date={G.date}/>{foot(9)}
      </div>

      {/* PAGE 10 — ANNEXE */}
      <div className="ppage">
        <div className="ph"><div><div className="ph-ref">{G.refDoc}</div><div className="ph-tit">Annexe — Note de Calcul</div><div className="ph-sub">{G.poste} · {G.tension} KV N°: {G.depart1}</div></div><div className="ph-r"><span className="badge badge-a">ANNEXE</span><div className="pg-note">Page 10/{T}</div></div></div>
        <PS title="Formules de Calcul">
          <div style={{background:"#f8fafc",padding:"3mm 4mm",fontFamily:"monospace",fontSize:"7pt",color:"#334155",lineHeight:1.9,borderRadius:2}}>
            {[
              `Z_total  = √(R²+X²) = √(${C.Rt}²+${C.Xt}²) = ${C.Zt} Ω`,
              `Angle    = arctan(X/R) = arctan(${C.Xt}/${C.Rt}) = ${C.ang}°`,
              `Facteur  = CT/VT = ${C.ctr}/${C.vtr} = ${C.cv}`,
              `Zd       = ${C.Zt} × ${C.cv} = ${C.Zd} Ω`,
              `kZ       = ${C.kz}  →  Z0 prim = ${C.Z0t} Ω  Z0d = ${C.Z0d} Ω`,
              `Z1       = Zd × ${zp.z1_pct}% = ${C.z1} Ω   |   Z2 = Zd × ${zp.z2_pct}% = ${C.z2} Ω`,
              `Zp       = Zd × ${zp.zp_pct}% = ${C.zP} Ω   |   Z3 = Zd × ${zp.z3_pct}% = ${C.z3} Ω`,
              `R1G      = Z3 × ${zp.r1g_factor} = ${C.r1g} Ω  |  R1Ph = Z3 × ${zp.r1ph_factor} = ${C.r1ph} Ω`,
              `Blinder  = 0.423 × Zd = ${C.blinder} Ω`,
              `7SA82 Kr = (R0-R1)/(3×R1) = ${R((C.Rt0-C.Rt)/(3*C.Rt),3)}`,
              `7SA82 Kx = (X0-X1)/(3×X1) = ${R((C.Xt0-C.Xt)/(3*C.Xt),3)}`,
            ].map((line,i)=><div key={i}>{line}</div>)}
          </div>
        </PS>
        <PS title="Tableau de Coordination des Temporisations">
          <table style={{width:"100%",borderCollapse:"collapse",fontSize:"7.5pt"}}>
            <thead><tr style={{background:"#1e293b",color:"white"}}>
              {["Fonction","Relais","Temporisation","Type","Remarque"].map(h=>(
                <th key={h} style={{padding:"1.5mm 2.5mm",fontWeight:600,textAlign:"left",fontSize:"6.5pt",textTransform:"uppercase"}}>{h}</th>
              ))}
            </tr></thead>
            <tbody>
              {[
                ["Z1","P444/D60/7SA82/REL670",zp.tZ1+" ms","Mono+TA","Instantané"],
                ["Z2","P444/D60/7SA82/REL670",zp.tZ2+" ms","3P","Sur-portée backup"],
                ["Zp pilote","P444",R(pf(zp.tZp)/1000,1)+" s","3P","Téléprotection"],
                ["Z3 sauveg.","P444/D60/REL670",R(pf(zp.tZ3)/1000,1)+" s","3P","Backup lointain"],
                ["50BF t2","DBF/P142",p142.bf_t2+" ms","3P-2bob.","CB défaillant"],
                ["67N","P142",p142.dir67n_t+" s","3P","Terre aval"],
              ].map(([f,r,t,d,rem],i)=>(
                <tr key={i} style={{borderBottom:".2mm solid #f1f5f9",background:i%2===0?"white":"#fafafa"}}>
                  <td style={{padding:"1.3mm 2.5mm",fontWeight:700}}>{f}</td>
                  <td style={{padding:"1.3mm 2.5mm",fontFamily:"monospace",color:"#1e40af",fontWeight:700}}>{r}</td>
                  <td style={{padding:"1.3mm 2.5mm",fontFamily:"monospace",fontWeight:700,color:"#92400e"}}>{t}</td>
                  <td style={{padding:"1.3mm 2.5mm"}}>{d}</td>
                  <td style={{padding:"1.3mm 2.5mm",color:"#64748b",fontStyle:"italic"}}>{rem}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </PS>
        <PSign by={G.elaborePar} date={G.date}/>{foot(10)}
      </div>

      </div>
    </>
  );
}

/* ══════════════════════════════════════════════
   MAIN APP
══════════════════════════════════════════════ */
export default function App() {
  const [tab, setTab]         = useState(0);
  const [showPrint, setShowPrint] = useState(false);

  /* ── STATE ── */
  const [G, setG] = useState({
    poste:"HASSAN 1er", tension:"225", depart1:"25-66 TAZARTE",
    date:"22/05/2025", ficheNo:"", elaborePar:"AHTTAB",
    refDoc:"DOS.FR01.DPS02", indice:"00",
  });
  const [segs, setSegs] = useState([
    {id:1, name:"Seg. 1", cable:"ALMEC 570", length:"48.553", r_km:"0.0700", x_km:"0.3959"},
    {id:2, name:"Seg. 2", cable:"ALAC 288",  length:"63.712", r_km:"0.1350", x_km:"0.4340"},
  ]);
  const [red, setRed] = useState({vt_prim:"220000",vt_sec:"100",ct_prim:"1000",ct_sec:"1"});
  const [zp, setZp]   = useState({
    z1_pct:"61.1",z2_pct:"120",zp_pct:"140",z3_pct:"175.6",z4_pct:"35.1",
    kz:"0.67",kz_arg:"0",tZ1:"0",tZ2:"400",tZ3:"3200",tZ4:"3200",tZp:"1000",
    r1g_factor:"1.45",r1ph_factor:"1.31",
  });
  const [p142, setP142] = useState({
    bf_i_phase:"0.10",bf_i_neutre:"0.10",bf_t1:"100",bf_t2:"150",bf_t3:"200",bf_t_reset:"30",
    i_inst_pct:"150",i_def_pct:"120",t_def:"0.5",
    dir67n_i0:"0.05",dir67n_t:"1.0",dir67n_angle:"75",
    u0_seuil:"5",u0_t:"1.5",tcs_i:"0.020",tcs_t:"2.0",
    r79_mode:"1",r79_t_dead1:"0.5",r79_t_dead2:"10",r79_t_rec:"30",r79_n_cycles:"2",in_nom:"1",
  });
  // 7SA82 specific
  const [sa82, setSa82] = useState({
    z1_pct:"70",z2_pct:"110",z3_pct:"181",z4_pct:"125",z5_pct:"630",
    z1_rpt:"4",z1_rpp:"4",z2_rpt:"5",z2_rpp:"5",z3_rpt:"6",z3_rpp:"6",
    z4_rpt:"7",z4_rpp:"7",z5_rpt:"7",z5_rpp:"7",
    tz1:"0",tz2:"300",tz3:"800",tz4:"2000",tz5:"2000",
  });
  // REL670 specific
  const [rel670, setRel670] = useState({
    zm01_pct:"80",zm02_pct:"120",zm03_pct:"130",zm04_pct:"290",zm05_pct:"58",
    rfpp1:"60",rfpe1:"70",rfpp2:"60",rfpe2:"70",rfpp3:"80",rfpe3:"88",
    psd_pct_fw:"347",psd_rf:"120",
  });

  const ug  = (k,v) => setG(s=>({...s,[k]:v}));
  const ur  = (k,v) => setRed(s=>({...s,[k]:v}));
  const uz  = (k,v) => setZp(s=>({...s,[k]:v}));
  const up  = (k,v) => setP142(s=>({...s,[k]:v}));
  const us  = (id,k,v) => setSegs(s=>s.map(x=>x.id===id?{...x,[k]:v}:x));
  const addSeg = () => setSegs(s=>[...s,{id:Date.now(),name:`Seg. ${s.length+1}`,cable:"ALMEC 570",length:"0",r_km:"0.0700",x_km:"0.3959"}]);
  const delSeg = id => setSegs(s=>s.length>1?s.filter(x=>x.id!==id):s);

  const onCableChange = (id,cable) => {
    const cb = CABLE_DB[cable];
    setSegs(s=>s.map(x=>x.id===id?{...x,cable,
      r_km: cb.r_km!==null ? String(cb.r_km) : x.r_km,
      x_km: cb.x_km!==null ? String(cb.x_km) : x.x_km,
    }:x));
  };

  /* ── CALCULATIONS ── */
  const C = useMemo(()=>{
    const segC = segs.map(s=>{
      const l=pf(s.length), r=pf(s.r_km,4), x=pf(s.x_km,4);
      return{...s,R:R(r*l,4),X:R(x*l,4),Z:R(Math.sqrt((r*l)**2+(x*l)**2),4),z_km:R(Math.sqrt(r**2+x**2),4)};
    });
    const Rt=segC.reduce((a,s)=>a+s.R,0), Xt=segC.reduce((a,s)=>a+s.X,0);
    const Zt=Math.sqrt(Rt**2+Xt**2), Lt=segs.reduce((a,s)=>a+pf(s.length),0);
    const ang=toDeg(Math.atan2(Xt,Rt));
    const VTp=pf(red.vt_prim),VTs=pf(red.vt_sec),CTp=pf(red.ct_prim),CTs=pf(red.ct_sec);
    const vtr=VTp/VTs, ctr=CTp/CTs, cv=ctr/vtr;
    const Zd=Zt*cv, Rd=Rt*cv, Xd=Xt*cv;
    const kz=pf(zp.kz,4), Z0t=Zt*(1+3*kz), Z0d=Z0t*cv;
    // Homopolaire primary
    const Rt0 = R(Rt*(1+3*kz),4), Xt0 = R(Xt*(1+3*kz),4);

    const z1=R(Zd*pf(zp.z1_pct)/100), z2=R(Zd*pf(zp.z2_pct)/100);
    const z3=R(Zd*pf(zp.z3_pct)/100), z4=R(Zd*pf(zp.z4_pct)/100);
    const zP=R(Zd*pf(zp.zp_pct)/100);
    const r1g=R(z3*pf(zp.r1g_factor)), r1ph=R(z3*pf(zp.r1ph_factor));
    const blinder=R(0.423*Zd), porteeAv=R(1.3*z2), porteeArr=R(0.35*Zd);
    const bf_ih=R(pf(p142.bf_i_phase)*ctr,3);
    const i_inst=R(CTp*pf(p142.i_inst_pct)/100,0), i_def=R(CTp*pf(p142.i_def_pct)/100,0);

    // 7SA82 zones (secondary)
    const ang_r = ang*Math.PI/180;
    const sa82_x = pct => R(Zd*Math.sin(ang_r)*pct/100, 3);
    const sa82_z1_x=sa82_x(pf(sa82.z1_pct)),sa82_z2_x=sa82_x(pf(sa82.z2_pct));
    const sa82_z3_x=sa82_x(pf(sa82.z3_pct)),sa82_z4_x=sa82_x(pf(sa82.z4_pct));
    const sa82_z5_x=sa82_x(pf(sa82.z5_pct));

    // REL670 zones (primary)
    const rel_x = pct => R(Xt*pct/100, 2);
    const rel_r = pct => R(Rt*pct/100, 2);
    const rel_x0 = pct => R(Xt0*pct/100, 2);
    const rel_r0 = pct => R(Rt0*pct/100, 2);
    const zm01p=pf(rel670.zm01_pct),zm02p=pf(rel670.zm02_pct),zm03p=pf(rel670.zm03_pct),zm04p=pf(rel670.zm04_pct),zm05p=pf(rel670.zm05_pct);

    // Power swing detection
    const psd_pct=pf(rel670.psd_pct_fw);
    const rel670_psd_x=R(Xt*psd_pct/100,2), rel670_psd_r=R(Rt*psd_pct/100,2);

    return {
      segC, Rt:R(Rt,4), Xt:R(Xt,4), Zt:R(Zt,4), Lt:R(Lt,3), ang:R(ang,2),
      Zd:R(Zd,3), Rd:R(Rd,3), Xd:R(Xd,3), Z0t:R(Z0t,4), Z0d:R(Z0d,3),
      Rt0, Xt0, vtr, ctr, cv:R(cv,5),
      z1,z2,z3,z4,zP,r1g,r1ph,blinder,porteeAv,porteeArr,kz,
      vt_sec_ph:R(VTs/Math.sqrt(3),1),
      bf_ih, i_inst, i_def,
      // 7SA82
      sa82_z1_x,sa82_z2_x,sa82_z3_x,sa82_z4_x,sa82_z5_x,
      sa82_z1_rpt:pf(sa82.z1_rpt),sa82_z1_rpp:pf(sa82.z1_rpp),
      sa82_z2_rpt:pf(sa82.z2_rpt),sa82_z2_rpp:pf(sa82.z2_rpp),
      sa82_z3_rpt:pf(sa82.z3_rpt),sa82_z3_rpp:pf(sa82.z3_rpp),
      sa82_z4_rpt:pf(sa82.z4_rpt),sa82_z4_rpp:pf(sa82.z4_rpp),
      sa82_z5_rpt:pf(sa82.z5_rpt),sa82_z5_rpp:pf(sa82.z5_rpp),
      sa82_tz1:sa82.tz1+"ms",sa82_tz2:R(pf(sa82.tz2)/1000,1)+"s",
      sa82_tz3:R(pf(sa82.tz3)/1000,1)+"s",sa82_tz4:R(pf(sa82.tz4)/1000,1)+"s",
      sa82_tz5:R(pf(sa82.tz5)/1000,1)+"s",
      // REL670
      rel670_z1_x:rel_x(zm01p),rel670_z1_r:rel_r(zm01p),rel670_z1_x0:rel_x0(zm01p),rel670_z1_r0:rel_r0(zm01p),
      rel670_z2_x:rel_x(zm02p),rel670_z2_r:rel_r(zm02p),rel670_z2_x0:rel_x0(zm02p),rel670_z2_r0:rel_r0(zm02p),
      rel670_zp_x:rel_x(zm03p),rel670_zp_r:rel_r(zm03p),rel670_zp_x0:rel_x0(zm03p),rel670_zp_r0:rel_r0(zm03p),
      rel670_z3_x:rel_x(zm04p),rel670_z3_r:rel_r(zm04p),rel670_z3_x0:rel_x0(zm04p),rel670_z3_r0:rel_r0(zm04p),
      rel670_z4_x:rel_x(zm05p),rel670_z4_r:rel_r(zm05p),rel670_z4_x0:rel_x0(zm05p),rel670_z4_r0:rel_r0(zm05p),
      rel670_rfpp1:pf(rel670.rfpp1),rel670_rfpe1:pf(rel670.rfpe1),
      rel670_rfpp2:pf(rel670.rfpp2),rel670_rfpe2:pf(rel670.rfpe2),
      rel670_rfpp3:pf(rel670.rfpp3),rel670_rfpe3:pf(rel670.rfpe3),
      rel670_psd_x,rel670_psd_r,rel670_psd_rf:pf(rel670.psd_rf),
      kz_r: kz, // simplified: assume same angle for homopolar
    };
  },[segs,red,zp,p142,sa82,rel670]);

  /* ══════════════════════════════════════════
     PRINT — The ONLY reliable way in Electron:
     Direct DOM manipulation + double rAF.
     DO NOT use React setState — Electron's
     Chromium calls window.print() before the
     React re-render cycle completes, producing
     a blank page.
  ══════════════════════════════════════════ */
  const doPrint = useCallback(() => {
    const el = document.getElementById("pdoc");
    if (!el) return;

    // 1. Show #pdoc via direct DOM — instant, no React cycle
    el.style.cssText = [
      "display:block!important",
      "position:fixed!important",
      "top:0!important",
      "left:0!important",
      "right:0!important",
      "bottom:0!important",
      "width:100vw!important",
      "height:100vh!important",
      "z-index:2147483647!important",
      "background:white!important",
      "overflow:auto!important",
      "visibility:visible!important",
    ].join(";");

    // 2. Double requestAnimationFrame → guarantees TWO paint frames
    //    before the print dialog fires (Chromium requirement)
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        // 3. Extra 250ms for Electron's renderer to finish compositing
        setTimeout(() => {
          window.print();
          // 4. Hide again after dialog closes (user can cancel or print)
          setTimeout(() => {
            el.style.cssText = "display:none!important";
          }, 1200);
        }, 250);
      });
    });
  }, []);

  /* ── Listen for Ctrl+P from Electron menu ── */
  useEffect(() => {
    if (window.electronAPI?.onMenuPrint) {
      window.electronAPI.onMenuPrint(() => doPrint());
    }
  }, [doPrint]);

  /* ── STYLES ── */
  const S = {
    app:    {minHeight:"100vh",background:"#020617",color:"#f1f5f9",fontFamily:"'Courier New',monospace"},
    topbar: {background:"#0f172a",borderBottom:"1px solid #1e293b",position:"sticky",top:0,zIndex:50},
    toprow: {maxWidth:1400,margin:"0 auto",padding:"10px 16px",display:"flex",alignItems:"center",justifyContent:"space-between",gap:12},
    logo:   {width:34,height:34,background:"#fbbf24",borderRadius:8,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,fontWeight:900,color:"#0f172a",flexShrink:0},
    tabs:   {background:"#0f172a",borderBottom:"1px solid #1e293b",position:"sticky",top:56,zIndex:40},
    tabrow: {maxWidth:1400,margin:"0 auto",padding:"0 16px",display:"flex",overflowX:"auto"},
    content:{maxWidth:1400,margin:"0 auto",padding:"20px 16px"},
    g2:     {display:"grid",gridTemplateColumns:"1fr 1fr",gap:20},
    g3:     {display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:16},
    btn:    {display:"flex",alignItems:"center",gap:8,padding:"8px 18px",background:"#fbbf24",color:"#0f172a",border:"none",borderRadius:10,fontSize:12,fontWeight:700,cursor:"pointer",flexShrink:0},
  };

  const TabBtn = ({id,icon,label}) => {
    const act = tab===id;
    return(
      <button onClick={()=>setTab(id)} style={{display:"flex",alignItems:"center",gap:6,padding:"11px 14px",
        fontSize:11,fontWeight:600,whiteSpace:"nowrap",flexShrink:0,cursor:"pointer",
        border:"none",borderBottomStyle:"solid",borderBottomWidth:2,
        borderBottomColor:act?"#fbbf24":"transparent",
        background:act?"rgba(251,191,36,.05)":"transparent",
        color:act?"#fbbf24":"#64748b",transition:"all .15s"}}>
        <span style={{fontSize:14}}>{icon}</span>{label}
      </button>
    );
  };

  /* ── TAB CONTENTS ── */
  const t0 = (
    <div style={{...S.g2,alignItems:"start"}}>
      <Card>
        <STi>Informations du Départ</STi>
        <IF label="Poste"         value={G.poste}       onChange={v=>ug("poste",v)}/>
        <IF label="Tension (kV)"  value={G.tension}     onChange={v=>ug("tension",v)} type="number" unit="kV"/>
        <IF label="Départ N°"     value={G.depart1}     onChange={v=>ug("depart1",v)}/>
        <IF label="Date"          value={G.date}        onChange={v=>ug("date",v)}/>
        <IF label="Fiche N°"      value={G.ficheNo}     onChange={v=>ug("ficheNo",v)}/>
        <IF label="Élaboré par"   value={G.elaborePar}  onChange={v=>ug("elaborePar",v)}/>
        <IF label="Référence doc" value={G.refDoc}      onChange={v=>ug("refDoc",v)}/>
        <IF label="Indice"        value={G.indice}      onChange={v=>ug("indice",v)}/>
      </Card>
      <div style={{display:"flex",flexDirection:"column",gap:16}}>
        <Card>
          <STi>Résumé des Calculs</STi>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <Stat label="Longueur" value={C.Lt} unit="km" sub={`${segs.length} segment(s)`} color="cyan"/>
            <Stat label="Z primaire" value={C.Zt} unit="Ω" sub={`∠${C.ang}°`} color="amber"/>
            <Stat label="R (Ω)" value={C.Rt} unit="Ω" color="slate"/>
            <Stat label="X (Ω)" value={C.Xt} unit="Ω" color="slate"/>
            <Stat label="Zd (sec.)" value={C.Zd} unit="Ω" sub={`CV=${C.cv}`} color="green"/>
            <Stat label="Angle" value={C.ang} unit="°" color="cyan"/>
          </div>
        </Card>
        <Card>
          <STi>Zones de Protection</STi>
          <table style={{width:"100%"}}>
            <thead><tr style={{borderBottom:"1px solid #1e293b"}}>
              {["Zone","Ω","%Zd","Tempo"].map(h=><th key={h} style={{padding:"4px 6px",fontSize:10,color:"#475569",fontWeight:600,textAlign:h==="Zone"?"left":"right"}}>{h}</th>)}
            </tr></thead>
            <tbody>
              {[{z:"Z1",v:C.z1,pct:zp.z1_pct,t:zp.tZ1+" ms"},{z:"Z2",v:C.z2,pct:zp.z2_pct,t:zp.tZ2+" ms"},
                {z:"Zp",v:C.zP,pct:zp.zp_pct,t:R(pf(zp.tZp)/1000,1)+" s"},{z:"Z3",v:C.z3,pct:zp.z3_pct,t:R(pf(zp.tZ3)/1000,1)+" s"},
                {z:"Z4↩",v:C.z4,pct:zp.z4_pct,t:R(pf(zp.tZ4)/1000,1)+" s"},
              ].map(row=>(
                <tr key={row.z} style={{borderBottom:"1px solid #0f172a"}}>
                  <td style={{padding:"5px 6px",fontSize:11,...mono,color:"#fbbf24",fontWeight:700}}>{row.z}</td>
                  <td style={{padding:"5px 6px",fontSize:11,...mono,textAlign:"right",color:"#f1f5f9"}}>{row.v}</td>
                  <td style={{padding:"5px 6px",fontSize:11,textAlign:"right",color:"#64748b"}}>{row.pct}%</td>
                  <td style={{padding:"5px 6px",fontSize:11,textAlign:"right",color:"#64748b"}}>{row.t}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>
    </div>
  );

  const t1 = (
    <Card>
      <STi>Segments de la Ligne — Câblothèque</STi>
      {/* Cable legend */}
      <div style={{display:"flex",gap:10,marginBottom:14,flexWrap:"wrap"}}>
        {Object.entries(CABLE_DB).map(([k,v])=>(
          <div key={k} style={{background:"#1e293b",borderRadius:6,padding:"4px 10px",fontSize:10,color:"#94a3b8",border:"1px solid #334155"}}>
            <span style={{color:"#fbbf24",fontWeight:700,...mono}}>{k}</span>
            {v.r_km!==null&&<span style={{marginLeft:6}}>R={v.r_km} · X={v.x_km}</span>}
          </div>
        ))}
      </div>
      <div style={{overflowX:"auto"}}>
        <table style={{width:"100%",minWidth:900}}>
          <thead><tr style={{borderBottom:"1px solid #1e293b"}}>
            {["Nom","Type Câble","Long. km","R Ω/km","X Ω/km","Z Ω/km","R Ω","X Ω","Z Ω",""].map((h,i)=>(
              <th key={i} style={{padding:"6px 8px",fontSize:10,color:"#64748b",fontWeight:600,textAlign:i>4?"right":"left"}}>{h}</th>
            ))}
          </tr></thead>
          <tbody>
            {C.segC.map(s=>(
              <tr key={s.id} style={{borderBottom:"1px solid #0f172a"}}>
                <td style={{padding:"4px 6px"}}>
                  <input value={s.name} onChange={e=>us(s.id,"name",e.target.value)}
                    style={{background:"#1e293b",border:"1px solid #334155",borderRadius:5,padding:"4px 8px",fontSize:11,color:"#f1f5f9",width:120,outline:"none"}}/>
                </td>
                <td style={{padding:"4px 6px"}}>
                  <select value={s.cable} onChange={e=>onCableChange(s.id,e.target.value)}
                    style={{background:"#1e293b",border:"1px solid #334155",borderRadius:5,padding:"4px 8px",fontSize:11,color:"#fbbf24",fontWeight:700,outline:"none",cursor:"pointer"}}>
                    {Object.keys(CABLE_DB).map(k=><option key={k} value={k}>{CABLE_DB[k].label}</option>)}
                  </select>
                </td>
                {[{k:"length",w:76,n:true},{k:"r_km",w:72,n:true},{k:"x_km",w:72,n:true}].map(({k,w,n})=>(
                  <td key={k} style={{padding:"4px 6px"}}>
                    <input value={s[k]} type={n?"number":"text"} onChange={e=>us(s.id,k,e.target.value)}
                      style={{background:"#1e293b",border:"1px solid #334155",borderRadius:5,padding:"4px 8px",fontSize:11,color:"#f1f5f9",...mono,width:w,outline:"none",textAlign:"right"}}/>
                  </td>
                ))}
                {[s.z_km,s.R,s.X,s.Z].map((v,i)=>(
                  <td key={i} style={{padding:"4px 8px",textAlign:"right",fontSize:11,...mono,
                    color:i===3?"#fbbf24":i>0?"#22d3ee":"#64748b",fontWeight:i>0?600:400}}>{v}</td>
                ))}
                <td style={{padding:"4px 6px"}}><button onClick={()=>delSeg(s.id)} style={{color:"#f87171",background:"none",border:"none",cursor:"pointer",fontSize:14}}>×</button></td>
              </tr>
            ))}
          </tbody>
          <tfoot><tr style={{borderTop:"2px solid rgba(251,191,36,.3)",background:"rgba(251,191,36,.04)"}}>
            <td colSpan={2} style={{padding:"8px 8px",fontSize:11,fontWeight:700,color:"#fbbf24"}}>TOTAL = {C.Lt} km</td>
            <td/><td/><td/><td style={{padding:"8px",textAlign:"right",fontSize:11,color:"#334155",...mono}}>—</td>
            {[C.Rt,C.Xt,C.Zt].map((v,i)=><td key={i} style={{padding:"8px",textAlign:"right",fontSize:11,...mono,fontWeight:700,color:"#fbbf24"}}>{v}</td>)}
            <td/>
          </tr></tfoot>
        </table>
      </div>
      <button onClick={addSeg} style={{marginTop:12,padding:"7px 16px",background:"rgba(251,191,36,.15)",border:"1px solid rgba(251,191,36,.3)",color:"#fbbf24",borderRadius:8,fontSize:11,cursor:"pointer"}}>+ Ajouter un segment</button>
    </Card>
  );

  const t2 = (
    <div style={{...S.g2,alignItems:"start"}}>
      <Card><STi>TT</STi>
        <IF label="Primaire (V)"   value={red.vt_prim} onChange={v=>ur("vt_prim",v)} type="number" unit="V"/>
        <IF label="Secondaire (V)" value={red.vt_sec}  onChange={v=>ur("vt_sec",v)}  type="number" unit="V"/>
        <IF label="Rapport TT"     value={`${C.vtr}:1`} readOnly/>
      </Card>
      <Card><STi>TC</STi>
        <IF label="Primaire (A)"   value={red.ct_prim} onChange={v=>ur("ct_prim",v)} type="number" unit="A"/>
        <IF label="Secondaire (A)" value={red.ct_sec}  onChange={v=>ur("ct_sec",v)}  type="number" unit="A"/>
        <IF label="Rapport TC"     value={`${C.ctr}:1`} readOnly/>
      </Card>
      <Card style={{gridColumn:"1/-1"}}>
        <STi>Conversion</STi>
        <p style={{fontSize:11,...mono,color:"#64748b",background:"#1e293b",borderRadius:8,padding:"8px 12px",border:"1px solid #334155",marginBottom:14}}>
          Zd = Z_prim × ({C.ctr}/{C.vtr}) = Z_prim × <span style={{color:"#fbbf24"}}>{C.cv}</span>
          &nbsp;&nbsp;|&nbsp;&nbsp; Z0d = Z0_prim × {C.cv} = <span style={{color:"#22d3ee"}}>{C.Z0d} Ω</span>
        </p>
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:10}}>
          <Stat label="Facteur conv." value={C.cv} color="amber"/>
          <Stat label="Zd (Ω)" value={C.Zd} unit="Ω" color="green"/>
          <Stat label="Z0d (Ω)" value={C.Z0d} unit="Ω" sub={`kZ=${C.kz}`} color="cyan"/>
          <Stat label="Angle" value={C.ang} unit="°" color="slate"/>
        </div>
      </Card>
    </div>
  );

  const t3 = (
    <div style={{...S.g2,alignItems:"start"}}>
      <Card>
        <STi>Portée des Zones (%Zd)</STi>
        {[["Zone 1 (%)","z1_pct","%"],["Zone 2 (%)","z2_pct","%"],["Zone 3 (%)","z3_pct","%"],
          ["Zone 4 Retour (%)","z4_pct","%"],["Zone P Pilote (%)","zp_pct","%"],
        ].map(([l,k,u])=><IF key={k} label={l} value={zp[k]} onChange={v=>uz(k,v)} type="number" unit={u}/>)}
        <STi>Compensation kZ</STi>
        <IF label="Facteur kZ"      value={zp.kz}     onChange={v=>uz("kz",v)}     type="number"/>
        <IF label="Argument kZ (°)" value={zp.kz_arg} onChange={v=>uz("kz_arg",v)} type="number" unit="°"/>
        <div style={{background:"#1e293b",borderRadius:8,padding:"8px 12px",border:"1px solid #334155",marginTop:8,fontSize:10,...mono,color:"#64748b"}}>
          Z0 prim = {C.Z0t} Ω &nbsp;|&nbsp; Z0d = {C.Z0d} Ω &nbsp;|&nbsp;
          7SA82 Kr={R((C.Rt0-C.Rt)/(3*C.Rt),3)} Kx={R((C.Xt0-C.Xt)/(3*C.Xt),3)}
        </div>
      </Card>
      <Card>
        <STi>Temporisations</STi>
        {[["tZ1 (ms)","tZ1","ms"],["tZ2 (ms)","tZ2","ms"],["tZ3 (ms)","tZ3","ms"],
          ["tZ4 (ms)","tZ4","ms"],["tZp (ms)","tZp","ms"],
        ].map(([l,k,u])=><IF key={k} label={l} value={zp[k]} onChange={v=>uz(k,v)} type="number" unit={u}/>)}
        <STi>Résistances (Quadrilatère)</STi>
        <IF label="Facteur R_G"  value={zp.r1g_factor}  onChange={v=>uz("r1g_factor",v)}  type="number" hint={`→${C.r1g}Ω`}/>
        <IF label="Facteur R_Ph" value={zp.r1ph_factor} onChange={v=>uz("r1ph_factor",v)} type="number" hint={`→${C.r1ph}Ω`}/>
      </Card>
      <Card style={{gridColumn:"1/-1"}}>
        <STi>Tableau des Zones</STi>
        <ZT zones={["Z1","Z2","Z3","Z4 Arr.","Zp"]} rows={[
          {lbl:"Portée (Ω)",vals:[C.z1,C.z2,C.z3,C.z4,C.zP],bold:true,hi:true},
          {lbl:"% de Zd",vals:[zp.z1_pct+"%",zp.z2_pct+"%",zp.z3_pct+"%",zp.z4_pct+"%",zp.zp_pct+"%"]},
          {lbl:"Comp. kZ",vals:[C.kz,C.kz,C.kz,C.kz,C.kz]},
          {lbl:"R1G (Ω)",vals:[C.r1g,C.r1g,C.r1g,C.r1g,C.r1g]},
          {lbl:"R1Ph (Ω)",vals:[C.r1ph,C.r1ph,C.r1ph,C.r1ph,C.r1ph]},
          {lbl:"Tempo.",vals:[zp.tZ1+" ms",zp.tZ2+" ms",R(pf(zp.tZ3)/1000,1)+" s",R(pf(zp.tZ4)/1000,1)+" s",R(pf(zp.tZp)/1000,1)+" s"],bold:true},
          {lbl:"Direction",vals:["Avant","Avant","Avant","Arrière","Aval"]},
        ]}/>
      </Card>
    </div>
  );

  // P444 — COMPLET
  const t4 = <div style={{display:"flex",flexDirection:"column",gap:14}}>
    <RHdr code="P444" name="ALSTOM / GE — Protection Distance" color="blue" poste={G.poste} tension={G.tension} dep1={G.depart1} date={G.date}/>

    {/* Row 1: Ligne + Réducteurs + Config */}
    <div style={S.g3}>
      <DTable title="Caractéristique de la Ligne" color="blue">
        {C.segC.map((s,i)=><>
          <DRow key={`ca${i}`} label={`Alliage Seg.${i+1}`} value={`${s.cable} — ${s.length} km`}/>
          <DRow key={`cr${i}`} label={`R / X Seg.${i+1}`}  value={`${s.R} / ${s.X} Ω`}/>
        </>)}
        <DRow label="Longueur TOTALE" value={`${C.Lt} km`} bold/>
        <DRow label="R / X Total"     value={`${C.Rt} / ${C.Xt} Ω`} bold/>
        <DRow label="Z Total (prim.)" value={`${C.Zt} Ω  ∠${C.ang}°`} bold/>
        <DRow label="Impédance Zd (sec.)" value={`${C.Zd} Ω`} hi/>
        <DRow label="Rapport TT" value={`${red.vt_prim}/√3 / ${red.vt_sec}/√3 V`} bold/>
        <DRow label="Rapport TC" value={`${red.ct_prim} / ${red.ct_sec} A`} bold/>
        <DRow label="Facteur conv. (TC/TT)" value={C.cv}/>
        <DRow label="Z0d (homopolaire)" value={`${C.Z0d} Ω`}/>
        <DRow label="kZ compensation" value={C.kz}/>
      </DTable>

      <DTable title="Configuration Générale" color="blue">
        <DRow label="Groupe réglages actifs"        value="Groupe 1"               bold/>
        <DRow label="Groupe réglages 1"             value="Activé"                 bold/>
        <DRow label="Groupe réglages 2/3/4"         value="Désactivé"/>
        <DRow label="Protection distance"           value="Activé"                 bold/>
        <DRow label="Détection pompage"             value="Activé"                 bold/>
        <DRow label="Protection ampèremétrique"     value="Désactivé"/>
        <DRow label="Protection Ii"                 value="Désactivé"/>
        <DRow label="Rupture conducteur"            value="Activé"                 bold/>
        <DRow label="Protection défaut terre"       value="Puissance wattmétrique" bold/>
        <DRow label="Comparaison directionnelle DEF" value="Désactivé"/>
        <DRow label="Protection voltmétrique"       value="Désactivé"/>
        <DRow label="Défaillance disjoncteur"       value="Désactivé"/>
        <DRow label="Supervision"                   value="Activé"                 bold/>
        <DRow label="Contrôle tension"              value="Activé"                 bold/>
        <DRow label="Réenclencheur"                 value="Activé"                 bold/>
        <DRow label="Surcharge thermique"           value="Désactivé"/>
        <DRow label="Rapports TC/TP"                value="Visible"/>
        <DRow label="Perturbographie"               value="Visible"/>
        <DRow label="Valeurs paramètres"            value="Secondaire"/>
      </DTable>

      <DTable title="Logique Distance" color="blue">
        <DRow label="Mode programme"       value="Schéma standard"/>
        <DRow label="Mode standard"        value="P.R.A.Z2"                  bold/>
        <DRow label="Type de défaut"       value="Tout type de défaut"/>
        <DRow label="Mode déclenchement"   value="Mono Z1Z2 et réception TA" bold/>
        <DRow label="Réception TA"         value="Autorisation Z2"           bold/>
        <DRow label="tInvCourantDéf"       value="20 ms"/>
        <DRow label="Logique déverrouillage" value="Aucun"/>
        <DRow label="Défail.Z1Ext"         value="Désactivé"/>
        <DRow label="Source faible / SF Mode" value="Désactivé"/>
        <DRow label="Perte de transit PDT" value="Désactivé"/>
        <DRow label="─── Mode enc/réenc ───" value=""/>
        <DRow label="Réencl. Z1 activée"   value="1" bold/>
        <DRow label="Réencl. Z2 activée"   value="1" bold/>
        <DRow label="Réencl. Z3 activée"   value="0"/>
        <DRow label="Réencl. toutes zones" value="0"/>
        <DRow label="Réencl. TAC"          value="1" bold/>
        <DRow label="Encl. toutes zones"   value="1" bold/>
        <DRow label="Encl. défaut U< et I>" value="1" bold/>
        <DRow label="Encl. Z1 / Z2 / Z3 activée" value="0 / 0 / 0"/>
        <DRow label="Encl. Z1+Zam / Z2+Zam" value="0 / 0"/>
        <DRow label="Encl. TAC / désactivé" value="0 / 0"/>
      </DTable>
    </div>

    {/* Row 2: Zones table */}
    <ZT zones={["Z1","Z2","Z3","Z4 (Arr.)","Zp (Pilote)"]} rows={[
      {lbl:"Portée (Ω sec.)",vals:[C.z1,C.z2,C.z3,C.z4,C.zP],bold:true,hi:true},
      {lbl:"% de Zd",vals:[zp.z1_pct+"%",zp.z2_pct+"%",zp.z3_pct+"%",zp.z4_pct+"%",zp.zp_pct+"%"]},
      {lbl:"Comp. kZ",vals:[C.kz,C.kz,C.kz,C.kz,C.kz]},
      {lbl:"Argument kZ",vals:["0°","0°","0°","0°","0°"]},
      {lbl:"R1G Ω/L",vals:[C.r1g,C.r1g,C.r1g,C.r1g,C.r1g]},
      {lbl:"R1Ph Ω/L",vals:[C.r1ph,C.r1ph,C.r1ph,C.r1ph,C.r1ph]},
      {lbl:"Temporisation",vals:[zp.tZ1+" ms",zp.tZ2+" ms",R(pf(zp.tZ3)/1000,1)+" s",R(pf(zp.tZ4)/1000,1)+" s",R(pf(zp.tZp)/1000,1)+" s"],bold:true},
      {lbl:"Direction",vals:["Avant","Avant","Avant","Arrière","Aval"]},
    ]}/>

    {/* Row 3: Pompage + Rupture + Puiss. homop. + Supervision TT */}
    <div style={S.g2}>
      <DTable title="Détection de Pompage" color="blue">
        <DRow label="Delta R" value={`${C.blinder} Ω`} hi/>
        <DRow label="Delta X" value={`${C.blinder} Ω`} hi/>
        <DRow label="État IN >" value="Activé" bold/>
        <DRow label="IN > (%max)" value="20 %" bold/>
        <DRow label="État Ii >" value="Activé" bold/>
        <DRow label="Ii > (%max)" value="20 %" bold/>
        <DRow label="État Imax Line>" value="Activé" bold/>
        <DRow label="Imax line>" value="2 A" bold/>
        <DRow label="Tempo de déverrouillage" value="5 s" bold/>
        <DRow label="Zones bloquées" value="111111" bold/>
        <DRow label="Perte de sync" value="1"/>
        <DRow label="Stable Swing" value="1"/>
      </DTable>

      <div style={{display:"flex",flexDirection:"column",gap:10}}>
        <DTable title="Rupture Conducteur" color="blue">
          <DRow label="Rupture conducteur" value="Activé" bold/>
          <DRow label="Réglages Ii/Id" value="200,0e-3" bold/>
          <DRow label="Tempo Ii/Id" value="60 sec alarme uniquement" bold/>
          <DRow label="Déclench Ii/Id" value="Désactivé"/>
        </DTable>

        <DTable title="Puissance Homopolaire (Défaut terre)" color="blue">
          <DRow label="État Puis. Hom." value="Actif" bold/>
          <DRow label="Coefficient K" value="0,6 sec" bold/>
          <DRow label="Tempo. de base" value="1,8 sec"/>
          <DRow label="Seuil I résiduel" value="0,1 A" bold/>
          <DRow label="Seuil Puis. Rés." value="0,6 VA" bold/>
        </DTable>
      </div>
    </div>

    {/* Row 4: Supervision TT + Contrôle système + Réenclencheur */}
    <div style={S.g3}>
      <DTable title="Supervision TT" color="blue">
        <DRow label="Temporisation FF" value="10 sec"/>
        <DRow label="Deverr FF / Ii et I₀" value="0,2 A" bold/>
        <DRow label="FF triphasé" value="Activé" bold/>
        <DRow label="Seuil 3P" value="12 V"/>
        <DRow label="Delta I>" value="0,2 A" bold/>
      </DTable>

      <DTable title="Contrôle de Système" color="blue">
        <DRow label="Ligne morte V<" value="12 V"/>
        <DRow label="Ligne vive V>" value="46 V" bold/>
        <DRow label="Barre morte V<" value="12 V"/>
        <DRow label="Barre vive V>" value="46 V" bold/>
        <DRow label="Tension diff." value="12 V"/>
        <DRow label="Fréquence diff." value="0,1 Hz" bold/>
        <DRow label="Phase diff." value="20 °" bold/>
        <DRow label="Tempo barre-ligne" value="0,5 sec" bold/>
      </DTable>

      <DTable title="Réenclencheur Automatique" color="blue">
        <DRow label="Mode monophasé" value="1" bold/>
        <DRow label="Mode triphasé" value="N.A"/>
        <DRow label="Tempo 1er cycle M" value="1,5 sec" bold/>
        <DRow label="Tempo 1er cycle T" value="N.A"/>
        <DRow label="Tempo 2ème cycle" value="N.A"/>
        <DRow label="Tempo 3ème / 4ème" value="N.A"/>
        <DRow label="Temporisation de blocage" value="60 sec" bold/>
        <DRow label="Tps ordre fermeture" value="0,1 s" bold/>
        <DRow label="Verrouillage et Blocage ARS" value="11111111111110" bold/>
      </DTable>
    </div>
  </div>;

  // D60 — COMPLET
  const t5 = <div style={{display:"flex",flexDirection:"column",gap:14}}>
    <RHdr code="D60" name="GE MULTILIN — Protection Distance" color="green" poste={G.poste} tension={G.tension} dep1={G.depart1} date={G.date}/>

    {/* Row 1: Système + Amorçage + Pendulaison */}
    <div style={S.g3}>
      <DTable title="Configuration Système" color="green">
        <DRow label="CT phase prim./sec." value={`${red.ct_prim} / ${red.ct_sec} A`} bold/>
        <DRow label="CT terre prim./sec." value={`${red.ct_prim} / ${red.ct_sec} A`} bold/>
        <DRow label="Rapport TT phase"    value={`${C.vtr}:1`} bold/>
        <DRow label="VT sec. ph-neutre"   value={`${C.vt_sec_ph} V`}/>
        <DRow label="Amplitude Z directe"      value={`${C.Zd} Ω`} hi/>
        <DRow label="Angle Z directe"          value={`${C.ang}°`} bold/>
        <DRow label="Amplitude Z homopolaire"  value={`${C.Z0d} Ω`} bold/>
        <DRow label="Angle Z homopolaire"      value={`${R(C.ang+0.24,2)}°`}/>
        <DRow label="Longueur de ligne"        value={`${C.Lt} km`} bold/>
        <DRow label="Unités longueur"          value="km"/>
        <DRow label="Facteur conv. TC/TT"      value={C.cv}/>
      </DTable>

      <DTable title="Amorçage de Ligne (Energisation)" color="green">
        <DRow label="Fonction"                        value="Activée" bold/>
        <DRow label="Source du signal"                value="Ligne (src 1)"/>
        <DRow label="Surintensité inst. mise ss T"    value="1,500 pu" bold/>
        <DRow label="Amorçage de sous-tension"        value="0,200 pu"/>
        <DRow label="Tempo. extrémité ligne ouverte"  value="65,535 s"/>
        <DRow label="Tempo. rappel extr. ouverte"     value="0,000 s"/>
        <DRow label="Tempo. amorçage sortie"          value="0,000 s"/>
        <DRow label="Contournement coord. réencl."    value="Désactivé"/>
        <DRow label="Tempo. amorçage coord. réencl."  value="0,045 s"/>
        <DRow label="Tempo. rappel coord. réencl."    value="0,005 s"/>
        <DRow label="Terminal ouvert"                 value="Hors"/>
        <DRow label="Verrouiller"                     value="Hors"/>
        <DRow label="Voyant"                          value="Verrouillé"/>
      </DTable>

      <div style={{display:"flex",flexDirection:"column",gap:10}}>
        <DTable title="Détection Pendulaison (Swing)" color="green">
          <DRow label="Fonction"           value="Activé" bold/>
          <DRow label="Source"             value="Ligne (src 1)"/>
          <DRow label="Forme"              value="Quad"/>
          <DRow label="Mode"               value="2 niveaux"/>
          <DRow label="Portée avant"       value={`${C.porteeAv} Ω`} hi/>
          <DRow label="Portée arrière"     value={`${C.porteeArr} Ω`} bold/>
          <DRow label="ACR avant/arrière"  value={`${C.ang}°`}/>
          <DRow label="Angle limite ext."  value="120 °"/>
          <DRow label="Angle limite moyen" value="90 °"/>
          <DRow label="Angle limite int."  value="60 °"/>
          <DRow label="Amorçage tempo 1"   value="0,030 s"/>
          <DRow label="Amorçage tempo 2"   value="0,017 s"/>
          <DRow label="Amorçage tempo 3"   value="5,000 s"/>
          <DRow label="Amorçage tempo 4"   value="0,017 s"/>
          <DRow label="Tempo auto-maintien" value="0,400 s"/>
          <DRow label="Mode déclenchement" value="Tôt" bold/>
        </DTable>

        <DTable title="Surtension Phase (59) + Fusible TT" color="green">
          <DRow label="Fonction 59"        value="Activé" bold/>
          <DRow label="Amorçage"           value="1,250 pu" hi/>
          <DRow label="Temporisation"      value="30 s Déclt" hi/>
          <DRow label="Tempo rappel"       value="0 s"/>
          <DRow label="Panne fusible TT"   value="Active" bold/>
          <DRow label="Prog. pilotes"      value="Activé (TDPSD mono)" bold/>
          <DRow label="Tempo auto-maint."  value="0,200 s"/>
          <DRow label="Rx1"                value="TD_Rx_MONO_En" bold/>
        </DTable>
      </div>
    </div>

    {/* Row 2: Zone Phase table */}
    <div style={{background:"#1e293b",borderRadius:8,padding:"6px 12px",marginBottom:4}}>
      <span style={{fontSize:11,fontWeight:700,color:"#4ade80",textTransform:"uppercase",letterSpacing:"0.08em"}}>Protection Distance Phase — 5 Zones</span>
    </div>
    <ZT accentColor="green" zones={["Z1","Z2","Z3 (Zp)","Z4 (Rev.)","Z5 (Z3bkp)"]} rows={[
      {lbl:"Fonction",vals:["Activé","Activé","Activé","Activé","Activé"]},
      {lbl:"Direction",vals:["Avant","Avant","Avant","Arrière","Avant"]},
      {lbl:"Forme",vals:["Quad","Quad","Quad","Quad","Quad"]},
      {lbl:"Portée (Ω sec.)",vals:[C.z1,C.z2,C.zP,C.z4,C.z3],bold:true,hi:true},
      {lbl:"ACR (°)",vals:[`${C.ang}°`,`${C.ang}°`,`${C.ang}°`,`${C.ang}°`,`${C.ang}°`]},
      {lbl:"Limite compensation",vals:["90°","90°","90°","90°","90°"]},
      {lbl:"Volet quadrant droit (Ω)",vals:[C.blinder,C.blinder,C.blinder,C.blinder,C.blinder]},
      {lbl:"Volet quadrant gauche (Ω)",vals:[C.blinder,C.blinder,C.blinder,C.blinder,C.blinder]},
      {lbl:"Surveillance",vals:["0,200 pu","0,200 pu","0,200 pu","0,200 pu","0,200 pu"]},
      {lbl:"Temporisation",vals:["0 s","0,400 s","1,000 s","3,200 s","3,200 s"],bold:true},
      {lbl:"Verrouiller",vals:["Verr PX1/FF","Verr PX1/FF","Verr PX1/FF","Verr PX1/FF","Verr PX1/FF"]},
    ]}/>

    {/* Row 3: Zone Terre table */}
    <div style={{background:"#1e293b",borderRadius:8,padding:"6px 12px",marginBottom:4}}>
      <span style={{fontSize:11,fontWeight:700,color:"#4ade80",textTransform:"uppercase",letterSpacing:"0.08em"}}>Protection Distance Terre — 5 Zones</span>
    </div>
    <ZT accentColor="green" zones={["Z1","Z2","Z3 (Zp)","Z4 (Rev.)","Z5 (Z3bkp)"]} rows={[
      {lbl:"Portée (Ω sec.)",vals:[C.z1,C.z2,C.zP,C.z4,C.z3],bold:true,hi:true},
      {lbl:"Amplitude Z0/Z1",vals:["3","3","3","3","3"]},
      {lbl:"Angle Z0/Z1 (°)",vals:["0,24°","0,24°","0,24°","0,24°","0,24°"]},
      {lbl:"Amplitude Z0M Z1",vals:["0,000","0,000","0,000","0,000","0,000"]},
      {lbl:"Volet quadrant droit (Ω)",vals:[C.blinder,C.blinder,C.blinder,C.blinder,C.blinder]},
      {lbl:"Volet quadrant gauche (Ω)",vals:[C.blinder,C.blinder,C.blinder,C.blinder,C.blinder]},
      {lbl:"Temporisation",vals:["0 s","0,400 s","1,000 s","3,200 s","3,200 s"],bold:true},
      {lbl:"Direction",vals:["Avant","Avant","Avant","Arrière","Avant"]},
    ]}/>
  </div>;

  // DBF
  const t6 = <div style={{display:"flex",flexDirection:"column",gap:14}}>
    <RHdr code="DBF" name="Défaillance Disjoncteur" color="orange" poste={G.poste} tension={G.tension} dep1={G.depart1} date={G.date}/>
    <div style={S.g2}>
      <DTable title="Réglages Généraux" color="orange">
        <DRow label="État" value="En service" bold/><DRow label="TC" value={`${red.ct_prim}/${red.ct_sec} A`} bold/>
        <DRow label="50BF 1P/3P" value="Permis" bold/><DRow label="3P Sans COU" value="Interdit"/>
      </DTable>
      <DTable title="Fonction 50BF (T1)" color="orange">
        <DRow label="Démarrage H/B" value="0,2 A" hi/><DRow label="t Mono T1" value="60 ms (deux bob.)" bold/>
        <DRow label="t 3P T2" value="60 ms" bold/><DRow label="t 2e Éch." value="200 ms (encadrants)" bold/>
      </DTable>
    </div>
  </div>;

  // D25
  const t7 = <div style={{display:"flex",flexDirection:"column",gap:14}}>
    <RHdr code="D25" name="SYNCHROCHEK" color="purple" poste={G.poste} tension={G.tension} dep1={G.depart1} date={G.date}/>
    <div style={S.g2}>
      <DTable title="Ligne" color="purple"><DRow label="Z / Zd" value={`${C.Zt}Ω / ${C.Zd}Ω`} bold/><DRow label="L" value={`${C.Lt} km`} bold/></DTable>
      <DTable title="Contrôleur F25" color="purple">
        <DRow label="CSS Ratio TT" value={`${C.vtr}:1`} hi/><DRow label="Déphasage" value="20 deg" bold/>
        <DRow label="Glis. fréq." value="100 mHz" bold/><DRow label="V vive" value="46 V" bold/><DRow label="V morte" value="12 V" bold/>
      </DTable>
    </div>
  </div>;

  // P142
  const t8 = <div style={{display:"flex",flexDirection:"column",gap:14}}>
    <RHdr code="P142" name="ALSTOM — 50BF+79+50/51+67N+59N+74" color="red" poste={G.poste} tension={G.tension} dep1={G.depart1} date={G.date}/>
    <div style={S.g3}>
      <Card><STi>50BF</STi>
        <IF label="I phase (A sec)"  value={p142.bf_i_phase}  onChange={v=>up("bf_i_phase",v)}  type="number" unit="A" hint={`→${C.bf_ih}A`}/>
        <IF label="t1/t2/t3 (ms)"   value={p142.bf_t2}       onChange={v=>up("bf_t2",v)}       type="number" unit="ms"/>
      </Card>
      <Card><STi>50/51 + 67N</STi>
        <IF label="I inst (% In)"    value={p142.i_inst_pct}  onChange={v=>up("i_inst_pct",v)}  type="number" unit="%" hint={`→${C.i_inst}A`}/>
        <IF label="I temp (% In)"    value={p142.i_def_pct}   onChange={v=>up("i_def_pct",v)}   type="number" unit="%" hint={`→${C.i_def}A`}/>
        <IF label="I0 67N (A sec)"   value={p142.dir67n_i0}   onChange={v=>up("dir67n_i0",v)}   type="number" unit="A"/>
      </Card>
      <Card><STi>79 + 59N</STi>
        <IF label="Mode (1=M,3=T)"   value={p142.r79_mode}    onChange={v=>up("r79_mode",v)}    type="number"/>
        <IF label="t mort cy.1 (s)"  value={p142.r79_t_dead1} onChange={v=>up("r79_t_dead1",v)} type="number" unit="s"/>
        <IF label="U0 seuil (V)"     value={p142.u0_seuil}    onChange={v=>up("u0_seuil",v)}    type="number" unit="V"/>
      </Card>
    </div>
  </div>;

  // 7SA82 Siemens
  const t9 = <div style={{display:"flex",flexDirection:"column",gap:14}}>
    <RHdr code="7SA82" name="SIEMENS — Protection Distance" color="sky" poste={G.poste} tension={G.tension} dep1={G.depart1} date={G.date}/>
    <div style={{background:"#0c1a3a",borderRadius:10,padding:12,marginBottom:4,fontSize:11,color:"#7dd3fc",border:"1px solid #0369a1"}}>
      ℹ️ Le 7SA82 utilise les valeurs <strong style={{color:"white"}}>secondaires</strong> (Ω/boucle) · Compensation par Kr et Kx ·
      Kr = {R((C.Rt0-C.Rt)/(3*C.Rt),3)} · Kx = {R((C.Xt0-C.Xt)/(3*C.Xt),3)} · Zd = <strong style={{color:"#fbbf24"}}>{C.Zd} Ω</strong>
    </div>
    <div style={S.g3}>
      <Card><STi>Portées des Zones (% Zd sec.)</STi>
        {[["Z1 Avant (%)","z1_pct"],["Z2 Avant (%)","z2_pct"],["Z3 Avant (%)","z3_pct"],
          ["Z4 Arrière (%)","z4_pct"],["Z5 Avant (%)","z5_pct"],
        ].map(([l,k])=><IF key={k} label={l} value={sa82[k]} onChange={v=>setSa82(s=>({...s,[k]:v}))} type="number" unit="%"/>)}
      </Card>
      <Card><STi>Résistances R(P-T) / R(P-P) en Ω</STi>
        {[["Z1 R(P-T)","z1_rpt"],["Z1 R(P-P)","z1_rpp"],["Z2 R(P-T)","z2_rpt"],["Z2 R(P-P)","z2_rpp"],
          ["Z3 R(P-T)","z3_rpt"],["Z3 R(P-P)","z3_rpp"],
        ].map(([l,k])=><IF key={k} label={l} value={sa82[k]} onChange={v=>setSa82(s=>({...s,[k]:v}))} type="number" unit="Ω"/>)}
      </Card>
      <Card><STi>Temporisations</STi>
        {[["tZ1 (ms)","tz1","ms"],["tZ2 (ms)","tz2","ms"],["tZ3 (ms)","tz3","ms"],["tZ4 (ms)","tz4","ms"],["tZ5 (ms)","tz5","ms"]].map(([l,k,u])=>(
          <IF key={k} label={l} value={sa82[k]} onChange={v=>setSa82(s=>({...s,[k]:v}))} type="number" unit={u}/>
        ))}
      </Card>
    </div>
    <ZT color="sky" zones={["Z1 (Fwd)","Z2 (Fwd)","Z3 (Fwd)","Z4 (Rev)","Z5 (Fwd)"]} rows={[
      {lbl:"Portée X (Ω sec.)",vals:[C.sa82_z1_x,C.sa82_z2_x,C.sa82_z3_x,C.sa82_z4_x,C.sa82_z5_x],bold:true,hi:true},
      {lbl:"R (P-T) Ω",vals:[C.sa82_z1_rpt,C.sa82_z2_rpt,C.sa82_z3_rpt,C.sa82_z4_rpt,C.sa82_z5_rpt]},
      {lbl:"R (P-P) Ω",vals:[C.sa82_z1_rpp,C.sa82_z2_rpp,C.sa82_z3_rpp,C.sa82_z4_rpp,C.sa82_z5_rpp]},
      {lbl:"Tempo (1ph/3ph)",vals:[C.sa82_tz1,C.sa82_tz2,C.sa82_tz3,C.sa82_tz4,C.sa82_tz5],bold:true},
      {lbl:"Direction",vals:["Avant","Avant","Avant","Arrière","Avant"]},
    ]}/>
    <DTable title="Ref. Document: F21_7SA82_N_182_BENGUERIR — Structure des paramètres" color="sky">
      <DRow label="Angle caract. prot. dist." value={`${C.ang}°`} bold/><DRow label="Kr (compensation R)" value={R((C.Rt0-C.Rt)/(3*C.Rt),3)} hi/>
      <DRow label="Kx (compensation X)" value={R((C.Xt0-C.Xt)/(3*C.Xt),3)} hi/><DRow label="Seuil 3I0>" value="1,25 A" bold/>
      <DRow label="Seuil U0>" value="3 V" bold/><DRow label="Anti-pompage (OSM)" value="Activé — tmax 5s" bold/>
    </DTable>
  </div>;

  // REL670
  const t10 = <div style={{display:"flex",flexDirection:"column",gap:14}}>
    <RHdr code="REL 670" name="ABB — Protection Distance" color="green" poste={G.poste} tension={G.tension} dep1={G.depart1} date={G.date}/>
    <div style={{background:"#052e16",borderRadius:10,padding:12,marginBottom:4,fontSize:11,color:"#86efac",border:"1px solid #14532d"}}>
      ℹ️ Le REL 670 utilise les valeurs <strong style={{color:"white"}}>primaires HT</strong> (Ω) ·
      X1 ligne = <strong style={{color:"#fbbf24"}}>{C.Xt} Ω</strong> ·
      R1 ligne = <strong style={{color:"#fbbf24"}}>{C.Rt} Ω</strong> ·
      X0 ligne = <strong style={{color:"#fbbf24"}}>{C.Xt0} Ω</strong>
    </div>
    <div style={S.g3}>
      <Card><STi>Portées ZM (%X1 prim.)</STi>
        {[["ZM01 Z1 Fwd (%)","zm01_pct"],["ZM02 Z2 Fwd (%)","zm02_pct"],["ZM03 Zp Fwd (%)","zm03_pct"],
          ["ZM04 Z3 Fwd (%)","zm04_pct"],["ZM05 Z4 Rev (%)","zm05_pct"],
        ].map(([l,k])=><IF key={k} label={l} value={rel670[k]} onChange={v=>setRel670(s=>({...s,[k]:v}))} type="number" unit="%"/>)}
      </Card>
      <Card><STi>RFPP / RFPE (Ω/l prim.)</STi>
        {[["RFPP ZM01","rfpp1","Ω"],["RFPE ZM01","rfpe1","Ω"],["RFPP ZM02","rfpp2","Ω"],["RFPE ZM02","rfpe2","Ω"],
          ["RFPP ZM03-05","rfpp3","Ω"],["RFPE ZM03-05","rfpe3","Ω"],
        ].map(([l,k,u])=><IF key={k} label={l} value={rel670[k]} onChange={v=>setRel670(s=>({...s,[k]:v}))} type="number" unit={u}/>)}
      </Card>
      <Card><STi>Power Swing (RPSD)</STi>
        <IF label="X1InFw (% X1 prim.)" value={rel670.psd_pct_fw} onChange={v=>setRel670(s=>({...s,psd_pct_fw:v}))} type="number" unit="%"/>
        <IF label="R1FInFw (Ω/l)" value={rel670.psd_rf} onChange={v=>setRel670(s=>({...s,psd_rf:v}))} type="number" unit="Ω"/>
        <div style={{marginTop:10,fontSize:10,...mono,color:"#64748b",background:"#1e293b",padding:"8px 10px",borderRadius:6}}>
          X1InFw = {C.rel670_psd_x} Ω&nbsp;|&nbsp;R1Lin = {C.rel670_psd_r} Ω
        </div>
      </Card>
    </div>
    <ZT color="green" zones={["ZM01 (Z1)","ZM02 (Z2)","ZM03 (Zp)","ZM04 (Z3)","ZM05 (Z4↩)"]} rows={[
      {lbl:"X1 (Ω prim.)",vals:[C.rel670_z1_x,C.rel670_z2_x,C.rel670_zp_x,C.rel670_z3_x,C.rel670_z4_x],bold:true,hi:true},
      {lbl:"R1 (Ω prim.)",vals:[C.rel670_z1_r,C.rel670_z2_r,C.rel670_zp_r,C.rel670_z3_r,C.rel670_z4_r],bold:true},
      {lbl:"X0 (Ω prim.)",vals:[C.rel670_z1_x0,C.rel670_z2_x0,C.rel670_zp_x0,C.rel670_z3_x0,C.rel670_z4_x0]},
      {lbl:"R0 (Ω prim.)",vals:[C.rel670_z1_r0,C.rel670_z2_r0,C.rel670_zp_r0,C.rel670_z3_r0,C.rel670_z4_r0]},
      {lbl:"RFPP (Ω/l)",vals:[C.rel670_rfpp1,C.rel670_rfpp2,C.rel670_rfpp3,C.rel670_rfpp3,C.rel670_rfpp3]},
      {lbl:"RFPE (Ω/l)",vals:[C.rel670_rfpe1,C.rel670_rfpe2,C.rel670_rfpe3,C.rel670_rfpe3,C.rel670_rfpe3]},
      {lbl:"tPP / tPE",vals:[zp.tZ1+" ms",zp.tZ2+" ms",R(pf(zp.tZp)/1000,1)+" s",R(pf(zp.tZ3)/1000,1)+" s",R(pf(zp.tZ4)/1000,1)+" s"],bold:true},
      {lbl:"Direction",vals:["Avant","Avant","Avant","Avant","Arrière"]},
    ]}/>
    <DTable title="Ref. Document: 25-57_TIZGUI — Paramètres additionnels REL 670" color="green">
      <DRow label="IBase" value={`${red.ct_prim} A`} bold/><DRow label="UBase" value={`${red.vt_prim/1000} kV`} bold/>
      <DRow label="X1InFw (PSD)" value={`${C.rel670_psd_x} Ω`} hi/><DRow label="R1Lin (PSD)" value={`${C.rel670_psd_r} Ω`} bold/>
      <DRow label="IMinOpPP" value="10 % IB" bold/><DRow label="IMinOpPE" value="5 % IB" bold/>
      <DRow label="tSOTF" value="0 s — Mode Niveau UI" bold/><DRow label="tDLD" value="150 ms" bold/>
      <DRow label="Schéma SOTF" value="PUTT-AZ" bold/>
    </DTable>
  </div>;

  const TABS = [
    {id:0,icon:"🏗",label:"Général",    content:t0},
    {id:1,icon:"〰",label:"Ligne",      content:t1},
    {id:2,icon:"🔁",label:"Réducteurs", content:t2},
    {id:3,icon:"📐",label:"Zones",      content:t3},
    {id:4,icon:"🔵",label:"P444",       content:t4},
    {id:5,icon:"🟢",label:"D60",        content:t5},
    {id:6,icon:"🟠",label:"DBF",        content:t6},
    {id:7,icon:"🟣",label:"D25",        content:t7},
    {id:8,icon:"🔴",label:"P142",       content:t8},
    {id:9,icon:"🔷",label:"7SA82",      content:t9},
    {id:10,icon:"🟩",label:"REL 670",   content:t10},
  ];

  return (
    <div style={S.app}>
      {/* ── Print Document (always in DOM, hidden until print) ── */}
      <PrintDoc G={G} C={C} zp={zp} red={red} p142={p142}/>

      {/* ── Print Modal ── */}
      {showPrint && (
        <div style={{position:"fixed",inset:0,zIndex:9999,display:"flex",alignItems:"center",justifyContent:"center",background:"rgba(0,0,0,.75)",backdropFilter:"blur(4px)"}}>
          <div style={{background:"#0f172a",border:"1px solid #334155",borderRadius:16,padding:28,width:"100%",maxWidth:480,margin:"0 16px",boxShadow:"0 25px 50px rgba(0,0,0,.5)"}}>
            <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:20}}>
              <div style={{width:44,height:44,background:"#fbbf24",borderRadius:12,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,flexShrink:0}}>🖨</div>
              <div>
                <div style={{fontSize:14,fontWeight:700,color:"#f1f5f9"}}>Imprimer le Rapport Complet</div>
                <div style={{fontSize:11,color:"#64748b",marginTop:2}}>10 pages A4 · P444 · D60 · DBF · D25 · P142 · 7SA82 · REL670</div>
              </div>
            </div>
            <div style={{background:"#1e293b",borderRadius:10,padding:14,border:"1px solid #334155",marginBottom:16}}>
              <div style={{fontSize:10,fontWeight:700,color:"#94a3b8",textTransform:"uppercase",letterSpacing:"0.1em",marginBottom:10}}>10 pages A4</div>
              {[["p.1","Page de Garde"],["p.2","Calculs Impédances"],["p.3","P444"],["p.4","D60"],
                ["p.5","DBF"],["p.6","D25"],["p.7","P142"],["p.8","7SA82 · Siemens"],["p.9","REL 670 · ABB"],["p.10","Annexe"],
              ].map(([pg,tit])=>(
                <div key={pg} style={{display:"flex",gap:10,alignItems:"center",marginBottom:5}}>
                  <span style={{fontSize:10,...mono,color:"#fbbf24",width:28,flexShrink:0}}>{pg}</span>
                  <span style={{fontSize:11,color:"#e2e8f0"}}>{tit}</span>
                </div>
              ))}
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8,marginBottom:12}}>
              {[["Poste",G.poste,"#fbbf24"],["Tension",G.tension+" kV","#f1f5f9"],["Zd",C.Zd+" Ω","#4ade80"]].map(([l,v,c])=>(
                <div key={l} style={{background:"#1e293b",borderRadius:8,padding:"8px 10px",textAlign:"center",border:"1px solid #334155"}}>
                  <div style={{fontSize:10,color:"#64748b"}}>{l}</div>
                  <div style={{fontSize:12,fontWeight:700,color:c,marginTop:2,...mono}}>{v}</div>
                </div>
              ))}
            </div>
            <div style={{fontSize:10,color:"#475569",textAlign:"center",marginBottom:16}}>
              💡 A4 Portrait · Marges minimales · Couleurs activées
            </div>
            <div style={{display:"flex",gap:10}}>
              <button onClick={()=>setShowPrint(false)} style={{flex:1,padding:"10px",background:"#1e293b",border:"1px solid #334155",color:"#94a3b8",borderRadius:10,fontSize:12,cursor:"pointer",fontWeight:600}}>Annuler</button>
              <button onClick={()=>{setShowPrint(false);doPrint();}} style={{flex:1,padding:"10px",background:"#fbbf24",border:"none",color:"#0f172a",borderRadius:10,fontSize:12,cursor:"pointer",fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",gap:6}}>
                🖨 Lancer l'impression
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Top Bar ── */}
      <div style={S.topbar}>
        <div style={S.toprow}>
          <div style={{display:"flex",alignItems:"center",gap:12}}>
            <div style={S.logo}>⚡</div>
            <div>
              <div style={{fontSize:12,fontWeight:700,color:"#f1f5f9",lineHeight:1}}>Calcul Réglage des Protections</div>
              <div style={{fontSize:10,color:"#475569",marginTop:2}}>ONEE · Branche Électricité · DCT</div>
            </div>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:12,fontSize:11,...mono,color:"#475569",flexWrap:"wrap"}}>
            <span style={{color:"#fbbf24",fontWeight:700}}>{G.poste}</span>
            <span>|</span><span>{G.tension} kV</span>
            <span>|</span><span>Zd=<span style={{color:"#4ade80"}}>{C.Zd}Ω</span></span>
            <span>|</span><span>L=<span style={{color:"#22d3ee"}}>{C.Lt}km</span></span>
            <span>|</span><span>∠{C.ang}°</span>
          </div>
          <button style={S.btn} onClick={()=>setShowPrint(true)}>
            <span style={{fontSize:16}}>🖨</span>
            <span>Imprimer le rapport</span>
          </button>
        </div>
      </div>

      {/* ── Tab Bar ── */}
      <div style={S.tabs}>
        <div style={S.tabrow}>
          {TABS.map(t=><TabBtn key={t.id} id={t.id} icon={t.icon} label={t.label}/>)}
        </div>
      </div>

      {/* ── Content ── */}
      <div style={S.content}>{TABS[tab].content}</div>

      {/* ── Footer ── */}
      <footer style={{borderTop:"1px solid #1e293b",background:"#0f172a",padding:"10px 16px",marginTop:40}}>
        <div style={{maxWidth:1400,margin:"0 auto",display:"flex",justifyContent:"space-between",fontSize:10,color:"#334155",...mono,flexWrap:"wrap",gap:8}}>
          <span>{G.refDoc} · Indice {G.indice} · {G.elaborePar} · {G.date}</span>
          <span>Z1={C.z1}Ω · Z2={C.z2}Ω · Zp={C.zP}Ω · Z3={C.z3}Ω · Zd={C.Zd}Ω</span>
        </div>
      </footer>
    </div>
  );
}
