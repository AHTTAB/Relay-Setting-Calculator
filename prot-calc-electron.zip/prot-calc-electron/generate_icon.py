#!/usr/bin/env python3
"""
Run this script ONCE to generate electron/icon.ico from the SVG.
Requires: pip install Pillow cairosvg
"""
import sys, os

def generate_icon():
    svg_content = """
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256">
  <rect width="256" height="256" rx="40" fill="#0f172a"/>
  <rect x="16" y="16" width="224" height="224" rx="28" fill="#1e293b"/>
  <polygon points="128,40 88,130 120,130 100,216 168,110 132,110 160,40" fill="#fbbf24"/>
  <text x="128" y="245" text-anchor="middle" font-family="Arial" font-size="22"
        font-weight="bold" fill="#94a3b8">ONEE-DCT</text>
</svg>
"""
    # Try cairosvg + Pillow
    try:
        import cairosvg
        from PIL import Image
        import io

        sizes = [16, 32, 48, 64, 128, 256]
        imgs = []
        for sz in sizes:
            png_data = cairosvg.svg2png(bytestring=svg_content.encode(), output_width=sz, output_height=sz)
            img = Image.open(io.BytesIO(png_data)).convert("RGBA")
            imgs.append(img)

        out = os.path.join(os.path.dirname(__file__), "electron", "icon.ico")
        imgs[0].save(out, format="ICO", sizes=[(s, s) for s in sizes],
                     append_images=imgs[1:])
        print(f"✅ Icon generated: {out}")
        return True
    except ImportError:
        print("⚠  cairosvg/Pillow not found. Using fallback PNG.")

    # Fallback: minimal 1×1 ICO (Electron will still work)
    import struct
    ico_header = struct.pack("<HHH", 0, 1, 1)          # reserved, type=1 (ICO), count=1
    ico_entry  = struct.pack("<BBBBHHII", 16, 16, 0, 0, 1, 32, 40+16*16*4, 22)
    bmp_header = struct.pack("<IIIHHIIIIII", 40, 16, 32, 1, 32, 0, 0, 0, 0, 0, 0)
    pixel = b"\xff\xbf\x0f\xff" * 256  # amber-ish
    mask  = b"\x00" * 32

    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "electron", "icon.ico")
    with open(out, "wb") as f:
        f.write(ico_header + ico_entry + bmp_header + pixel + mask)
    print(f"✅ Minimal icon generated: {out}")

if __name__ == "__main__":
    generate_icon()
